<?php
namespace app\index\controller;
use think\Controller;
use think\Request;
use think\Db;
class Index extends Controller
{
    public function index()
    {
      $data= Db::table('article')->order('id desc')->paginate(10);
//      dump($data);
//      die;
//                echo getcwd() . "<br/>"; 
//echo dirname(__FILE__);
           $page = $data->render();
           $num=$data->lastPage;
           $currentPage=$data->currentPage;
       $this->assign('data',$data);
       $this->assign('page', $page);
       $this->assign('num', $num);
       $this->assign('currentPage',$currentPage);

     return $this->fetch();
//     $view = new View();
//$view->name = 'thinkphp';
//return $view->fetch();
//     return view('hello',['name'=>'thinkphp']);
    }
    public function content()
    {  
        $id=Request::instance()->param('id');
//         dump($data);
        
//      $id=input('post.');
//                dump($id);
//            die;
        $data=Db::table('article')->where('id',$id)->find();
        
//        dump($data);
//        die;
         $this->assign('data',$data);
     return $this->fetch();
//        echo $id;
//     echo $name;
//             
//        return view();
    }
    public function news(){
//        return 'news';
    
       return view();
    }
     public function record(){
        
    
       return view();
    }
    //写文章
   public function write(){
       //判断如果没有提交数据返回页面 如果有数据就说明是插入  binggfanhuiyemian
          if( $data=input('post.')){ 
               $data['date']=time();
      Db::table('article')->insert($data);
      
          }
       return view();
    } 
    public function store(){
//       $data= Request::instance()->param();
//        $data=Request::instance()->param('title');
     
            
               
//               echo $data['title'];
//        $date=Request::instance()->param();
//        $data = ['foo' => 'bar', 'bar' => 'foo'];
            
              
//        dump($data);
        
        
//     if (request()->isGet()){  
//         $data=input('post.');  
//         dump($data);
//     }
//     else {
//         echo "no";
//         
//     }
    
//return $this->redirect('write');
    }
      public function sousuo(){
          if( $key= input('key')){        
         $data= Db::table('article')->where('title',$key)->order('id desc')->select();//第一个判断 输入关键字传入数据
//            $data= Db::query("select * from article where title like $key");
             
          }else if($cate= input('cate')){//第二个判断 标签分类传入数据
           $data= Db::table('article')->where('cate_id',$cate)->select();

          }
          else{//否则渲染输出
       $data= Db::table('article')->order('id desc')->paginate(15);
     
           }
       $this->assign('data',$data);
         
       return view();
    }
     public function message(){//留言
        
         $data= Db::table('message')->order('id desc')->paginate(15);
//      dump($data);
//      die;
//                echo getcwd() . "<br/>"; 
//echo dirname(__FILE__);
           $page = $data->render();
           $num=$data->lastPage;//总共页数  protected修饰  改成public  强制使用
           $currentPage=$data->currentPage;//当前数目

       $this->assign('data',$data);
       $this->assign('page', $page);
       $this->assign('num', $num);
       $this->assign('currentPage',$currentPage);

     return $this->fetch();
    }
    
     public function  leaveMes(){//ajax留言
         $input=[];
       $input['content']=Request::instance()->post('content');
   
       
        $input['date']=time();
//        echo $input['date'];
         Db::table('message')->insert($input);
     $data=[
         
         'stat'=>98,
     ];
           
 return $data; 
    }
    
    public function set(){
        
        
           if($id=Request::instance()->post('article')){//如果提交的是文章id  
               
               Db::table('article')->where("id= $id")->delete();//  删除文章
              return $id;
           }elseif($id=Request::instance()->post('message')){//如果提交的是留言id
               
               Db::table('message')->where("id= $id")->delete();  
              return $id;
           }else{ //如果没有提交任何数据  
             $article= Db::table('article')->order('id desc')->select();
//             var_dump($article);
             $message= Db::table('message')->order('id desc')->select();
              $this->assign('article',$article);
              $this->assign('message',$message);
            return view();
           }
            
     }
     public function login(){
        $password=Request::instance()->post('password');
        
        if($password=='111111'){
        
        return true;
        
        
        }
        else
            {return false;}
        
     }
     public function link(){
         if($input=Request::instance()->post('')){
             
             
              Db::table('favorate')->insert($input);
         return true; 
             
         }
         
         else {
             $data= $article= Db::table('favorate')->select();
             
             $this->assign('data',$data);
             return view();
         }
     }

  

     
}
