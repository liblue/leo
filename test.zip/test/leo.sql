-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 �?01 �?15 �?02:23
-- 服务器版本: 5.5.53
-- PHP 版本: 5.6.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `leo`
--

-- --------------------------------------------------------

--
-- 表的结构 `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `content` text NOT NULL,
  `saying` varchar(64) NOT NULL,
  `sayer` varchar(32) NOT NULL DEFAULT '麦其家的傻子',
  `cate_id` varchar(12) NOT NULL,
  `date` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=90 ;

--
-- 转存表中的数据 `article`
--

INSERT INTO `article` (`id`, `title`, `content`, `saying`, `sayer`, `cate_id`, `date`) VALUES
(28, '三都赋三', '阿打算', '', '', '', '1515227394'),
(23, '6666', '66666', '', '', '3', '1515222166'),
(22, '4444', '4444', '', '', '4', '1515222151'),
(75, '2222', '22222', '', '', '', '1515566143'),
(27, '三都赋三', '阿打算', '', '', '', '1515227280'),
(18, '第三方第三方', '阿斯蒂芬发射的', '', '', '', '1515222115'),
(29, '奥术大师', '奥术大师', '', '', '', '1515227399'),
(69, '1111', '111', '111', '1111', '', '1515382721'),
(68, 'layui（谐音：类UI) 是一款采用自身模块规范编写的前端 UI 框架，遵循原生 HTML/CSS/JS 的书写与组织形式，门', '其外在极简，却又不失饱满的内在，体积轻盈，组件丰盈，从核心代码到 API 的每一处细节都经过精心雕琢，非常适合界面的快速开发。layui 首个版本发布于2016年金秋，她区别于那些基于 MVVM 底层的 UI 框架，却并非逆道而行，而是信奉返璞归真之道。准确地说，她更多是为服务端程序员量身定做，你无需涉足各种前端工具的复杂配置，只需面对浏览器本身，让一切你所需要的元素与交互，从这里信手拈来。', '', '', '', '1515375025'),
(32, 'in不仅允许你传入layer内置的样式class名，还可以传入您自定义的class名。这是一个很好的切', '岛上书店', '', '', '', '1515227528'),
(41, '鼎折覆餗', '阿斯顿发生', '', '', '', '1515227998'),
(48, '多撒是', '阿打算', '', '', '', '1515228484'),
(67, '敖德萨所', '阿萨德', '', '', '', '1515228674'),
(71, '111', '11111', '111', '111', '', '1515462419'),
(72, '111', '11111', '111', '111', '', '1515462473'),
(89, '555', '555', '5555', '555', '', '1515566442');

-- --------------------------------------------------------

--
-- 表的结构 `cate`
--

CREATE TABLE IF NOT EXISTS `cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `favorate`
--

CREATE TABLE IF NOT EXISTS `favorate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `favorate`
--

INSERT INTO `favorate` (`id`, `title`, `link`) VALUES
(1, '111', 'https://www.baidu.com/'),
(2, '222', '2222'),
(3, '666', '666'),
(4, '555', '5555'),
(5, '8888', '8888'),
(6, '0000', '00000'),
(7, 'fdvgsdf', 'sdfgdf'),
(8, 'fsdfas', 'fsda'),
(9, 'dsfsad', 'dsfasdf'),
(10, '百度', 'http://'),
(11, '111', 'http://www.baidu.com'),
(12, '1111', 'http://111'),
(13, '收到', 'http://');

-- --------------------------------------------------------

--
-- 表的结构 `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `date` varchar(32) NOT NULL,
  `favorate` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=49 ;

--
-- 转存表中的数据 `message`
--

INSERT INTO `message` (`id`, `content`, `date`, `favorate`) VALUES
(1, 'sdcasddfs', '1515203468', 0),
(2, 'wwwwwwwww', '1515205740', 0),
(3, 'dfasfdad', '1515206124', 0),
(4, 'dfsdfsdf', '1515206128', 0),
(5, '111111', '1515206131', 0),
(7, '333333', '1515206146', 0),
(8, '444444', '1515206148', 0),
(9, '555555', '1515206150', 0),
(10, '55555', '1515206152', 0),
(11, '666666', '1515206154', 0),
(25, 'dsfasdfsdaf', '1515206826', 0),
(16, 'gfhfdghfg', '1515206382', 0),
(17, 'fghdfgh', '1515206384', 0),
(24, 'sdfsdfsdf', '1515206519', 0),
(20, 'fdgdsfg', '1515206479', 0),
(21, 'fdgfdg', '1515206482', 0),
(41, '阿斯顿发生的', '1515227272', 0),
(23, 'fdgdfgdfg', '1515206486', 0),
(27, '洒洒水\n', '1515206925', 0),
(28, '22222', '1515207133', 0),
(29, '扰扰攘攘仍然', '1515207141', 0),
(43, '森特股份', '1515384081', 0),
(31, '斯蒂芬斯蒂芬', '1515208058', 0),
(32, '得分大师傅都是', '1515208062', 0),
(33, '三都赋三', '1515208073', 0),
(42, '当时发生的', '1515227274', 0),
(35, '下载程序正常', '1515208167', 0),
(45, 'sdasdasdasssssssssssssssssssssssssssss', '1515398224', 0),
(46, 'gfggggggggg\nggggggggggggg', '1515398273', 0),
(47, '啊说什么啊说什么啊说什么啊说什么啊说什么啊说什么啊说什么啊说什么啊说什么啊说什么啊说什么啊说什么啊说什么', '1515398552', 0),
(48, 'dsfasdf', '1515642362', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
