<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"D:\0000000\phpStudy\WWW\test\public/../application/index\view\index\news.html";i:1514943398;}*/ ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <div>index控制器 add方法erwret</div>
    </body>
</html>
