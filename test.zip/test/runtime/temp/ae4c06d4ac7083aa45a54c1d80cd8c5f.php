<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:79:"D:\0000000\phpStudy\WWW\test\public/../application/index\view\index\record.html";i:1515571441;s:80:"D:\0000000\phpStudy\WWW\test\public/../application/index\view\public\header.html";i:1515664460;}*/ ?>

<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
<meta charset="UTF-8"><meta name="theme-color" content="#ccc">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>leo博客</title>
<link type="text/css" rel="stylesheet" href="__ROOT__/static/index/css/style.css">
<link type="text/css" rel="stylesheet" href="__ROOT__/static/index/layui/css/layui.css">
      <script  src="__ROOT__/static/index/js/jquery.min.js"/>  </script>
          <script  src="__ROOT__/static/index/layui/layui.js"/>  </script>
</head>
<body>

<div class="side">
<div class="overlay"><a href="" class="toc-btn iconfont icon-liebiao itip ifixed" id="art_dir" ></a></div>
<header class="content"  style="height:90%;padding-top: 30px">
      <nav>
	<ul>
		<li>   <a href="<?php echo url('/'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe68e;</i></span></a>
                    <a href="<?php echo url('message'); ?>" ><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;"  >&#xe63a;</i></span></a>
                    
                      <a href="<?php echo url('sousuo'); ?>"> <span class="iconfont icon-biaoqian itip ifixed" id="tags" > <i class="layui-icon" style="font-size: 30px; color: gray;">&#xe615;</i> </span> </a>
                    <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a>
		</li>
	</ul>
</nav>
    

    <nav>
        
	<ul>
            
         
		<li><a href="<?php echo url('message'); ?>" ><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;"  >&#xe611;</i></span></a>
                    
                      <a href="<?php echo url('sousuo'); ?>"> <span class="iconfont icon-biaoqian itip ifixed" id="tags" > <i class="layui-icon" style="font-size: 30px; color: gray;">&#xe615;</i> </span> </a>
	     <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a>
                    <a href="<?php echo url('link'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe64d;</i></span></a>
		</li>
	</ul>
</nav>
    
    
   
    <div  style="width: 100%;height:40%;padding-top:50px" >
       



    </div>

         
              <p>万头攒动火树银花之处不必找我。如欲相见，我在各种悲喜交集处。
</p>
            <p  style="float:right">——木心</p>

       </header>     
<footer> 
        	 
        <hgroup><h1>
                <a href="javascript:clickme();" class="itip ifixed" id="logofont" >&nbsp;I&nbsp;AM&nbsp; A &nbsp;LEO</a>
        
    </h1>


</hgroup>
<a href="<?php echo url('/'); ?>">
	<img class="avatar itip ifixed" id="logoicon" src="__ROOT__/static/index/img/shouye1.jpg" 
	/>
</a>
<!--
    <div><a href="{/}" target="_blank" style="font-size:14px;">About Me </a></div>
        <a href="{/}" target="_blank" style="font-size:14px;"><img src="__ROOT__/static/index/img/git.jpeg"  width="40px" height="30px"></a>-->

</footer>
</div>
       


   <main class="classify">
<!--           <div class="search__header fn-clear">
    <div class="search__input fn-left">
        <input placeholder="请输入关键字" value="" id="keyword" onkeypress="if(event.keyCode===13){document.getElementById('searchBtn').click()}">
        <button id="searchBtn" onclick="window.location.href='https://zixizixi.cn/search?keyword=' + document.getElementById('keyword').value"><i class="layui-icon" style="font-size: 30px; color: #1E9FFF;">&#xe615;</i></button>
    </div>
</div>-->

  
	<article>
		<header>
			<h2>
				<a  href="">
                                  
					
				</a>
			</h2>
		</header>
		<ul class="tags fn-clear"  style='margin-left:30px'>
			<li>
				<a class="tag" href=""
				   title="2017 年 09 月(3)">
					2017 年 09 月(3)</a>
			</li>
			<li>
				<a class="tag" href=""
				   title="2017 年 05 月(1)">
					2017 年 05 月(1)</a>
			</li>
			<li>
				<a class="tag" href=""
				   title="2017 年 04 月(3)">
					2017 年 04 月(3)</a>
			</li>
			<li>
				<a class="tag" href=""
				   title="2017 年 03 月(6)">
					2017 年 03 月(6)</a>
			</li>
			<li>
				<a class="tag" href=""
				   title="2017 年 02 月(10)">
					2017 年 02 月(10)</a>
			</li>
			<li>
				<a class="tag" href=""
				   title="2017 年 01 月(5)">
					2017 年 01 月(5)</a>
			</li>
			<li>
				<a class="tag" href=""
				   title="2016 年 12 月(2)">
					2016 年 12 月(2)</a>
			</li>
		</ul>
	</article>
<footer class="footer">

</footer>


</main>

    
    
</body>
</html>
<!-- Generated by Latke (https://github.com/b3log/latke) in 47ms, 2018/01/03 09:55:11 -->