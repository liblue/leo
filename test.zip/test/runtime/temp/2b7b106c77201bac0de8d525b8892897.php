<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:79:"D:\0000000\phpStudy\WWW\test\public/../application/index\view\index\sousuo.html";i:1515647268;s:80:"D:\0000000\phpStudy\WWW\test\public/../application/index\view\public\header.html";i:1515664460;}*/ ?>

<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
<meta charset="UTF-8"><meta name="theme-color" content="#ccc">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>leo博客</title>
<link type="text/css" rel="stylesheet" href="__ROOT__/static/index/css/style.css">
<link type="text/css" rel="stylesheet" href="__ROOT__/static/index/layui/css/layui.css">
      <script  src="__ROOT__/static/index/js/jquery.min.js"/>  </script>
          <script  src="__ROOT__/static/index/layui/layui.js"/>  </script>
</head>
<body>

<div class="side">
<div class="overlay"><a href="" class="toc-btn iconfont icon-liebiao itip ifixed" id="art_dir" ></a></div>
<header class="content"  style="height:90%;padding-top: 30px">
      <nav>
	<ul>
		<li>   <a href="<?php echo url('/'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe68e;</i></span></a>
                    <a href="<?php echo url('message'); ?>" ><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;"  >&#xe63a;</i></span></a>
                    
                      <a href="<?php echo url('sousuo'); ?>"> <span class="iconfont icon-biaoqian itip ifixed" id="tags" > <i class="layui-icon" style="font-size: 30px; color: gray;">&#xe615;</i> </span> </a>
                    <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a>
		</li>
	</ul>
</nav>
    

    <nav>
        
	<ul>
            
         
		<li><a href="<?php echo url('message'); ?>" ><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;"  >&#xe611;</i></span></a>
                    
                      <a href="<?php echo url('sousuo'); ?>"> <span class="iconfont icon-biaoqian itip ifixed" id="tags" > <i class="layui-icon" style="font-size: 30px; color: gray;">&#xe615;</i> </span> </a>
	     <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a>
                    <a href="<?php echo url('link'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe64d;</i></span></a>
		</li>
	</ul>
</nav>
    
    
   
    <div  style="width: 100%;height:40%;padding-top:50px" >
       



    </div>

         
              <p>万头攒动火树银花之处不必找我。如欲相见，我在各种悲喜交集处。
</p>
            <p  style="float:right">——木心</p>

       </header>     
<footer> 
        	 
        <hgroup><h1>
                <a href="javascript:clickme();" class="itip ifixed" id="logofont" >&nbsp;I&nbsp;AM&nbsp; A &nbsp;LEO</a>
        
    </h1>


</hgroup>
<a href="<?php echo url('/'); ?>">
	<img class="avatar itip ifixed" id="logoicon" src="__ROOT__/static/index/img/shouye1.jpg" 
	/>
</a>
<!--
    <div><a href="{/}" target="_blank" style="font-size:14px;">About Me </a></div>
        <a href="{/}" target="_blank" style="font-size:14px;"><img src="__ROOT__/static/index/img/git.jpeg"  width="40px" height="30px"></a>-->

</footer>
</div>
       


<link type="text/css" rel="stylesheet" href="__ROOT__/static/index/css/style1.css">


   <main class="classify">
       
       
           <div class="search__header fn-clear"   >
    <div class="search__input fn-left" >
        <input placeholder="请输入。。。" value="" id="keyword" name="key" onkeypress="if(event.keyCode===13){document.getElementById('searchBtn').click()}">
        <a    onclick="funs()"  > <button   class="layui-btn"  style="    background: none;border:none;"><img src="__ROOT__/static/index/img/sousuo.png"  style="width:30px;height:30px"/></button></a>
          <!--<a  href="/"  > <button   class="layui-btn"  style="    background-color: #88acdb"><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe615;</i></button></a>-->
    </div>
</div>

       <div  style="margin-top:80px" >

        
	<article>
            
		<header style="border-left:none">
			
		</header>
		<ul class="tags fn-clear"  style='margin-left:30px'>
                    
			<li>
				<a class="tag" style="background-color:#7AC5CD;" href="<?php echo url('sousuo','cate=1'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
                        <li>
				<a class="tag" style="background-color:#708090" href="<?php echo url('sousuo','cate=1'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
                        <li>
				<a class="tag" style="background-color:#E6E6FA" href="<?php echo url('sousuo','cate=2'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
                        <li>
				<a class="tag" style="background-color:#DCDCDC" href="<?php echo url('sousuo','cate=2'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
                        <li>
				<a class="tag" style="background-color:#BEBEBE" href="<?php echo url('sousuo','cate=2'); ?>"
				   title="2017 年 09 月(3)">
					2017 年 09 月(3)</a>
			</li>
                        <li>
				<a class="tag" style="background-color:#88acdb" href="<?php echo url('sousuo','cate=3'); ?>"
				   title="2017 年 09 月(3)">
					2017 年 09 月(3)</a>
			</li>
                        <li>
				<a class="tag" style="background-color:#DCDCDC" href="<?php echo url('sousuo','cate=3'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
                        <li>
				<a class="tag" style="background-color:#7A8B8B" href="<?php echo url('sousuo','cate=3'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
                        <li>
				<a class="tag" style="background-color:#9BCD9B" href="<?php echo url('sousuo','cate=3'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
                        <li>
				<a class="tag" style="background-color:#EEA9B8" href="<?php echo url('sousuo','cate=3'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
                        <li>
				<a class="tag" style="background-color:#B5B5B5" href="<?php echo url('sousuo','cate=111'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
                        <li>
				<a class="tag" style="background-color:#9AC0CDs" href="<?php echo url('sousuo','cate=3'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
                        <li>
				<a class="tag" style="background-color:#CDC9C9" href="<?php echo url('sousuo','cate=3'); ?>"
				   title="2017 年 09 月(3)">
					2017 </a>
			</li>
			
		</ul>
	</article>
           
<!--	<article>
		<header  style="border-left:none">
			
		</header>
		<ul class="tags fn-clear"  style="margin-left:30px;">
			<li>
				<a class="tag" href="https://zixizixi.cn/archives/2017/09"
				   title="2017 年 09 月(3)">
					2017 年 09 月(3)</a>
			</li>
		
			
		</ul>
	</article>-->
   <?php foreach($data as $v): ?>
<article>
    
     <div style="border:2px solid  none;width:50px;height:0px"></div>    
 <div style="border:2px solid none;width:0px;height:48px"></div>  
<header   style="margin-top:-40px">
	<h2>
            <a rel="bookmark" href="<?php echo url('content','id'.'='.$v['id']); ?>"><?php echo $v['title']; ?></a>
	
	</h2>

</header>
    <section class="abstract">
<p><?php echo date("Y-m-d",$v['date']); ?>&nbsp;&nbsp;<a href=""><?php echo $v['content']; ?></a></p>
    
    
    </section>
    <footer class="tags"  style="height:30px">
      <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe62a;</i></span></a>
	 <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a>
		     <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a>
	

 <div style="border:2px solid none;width:0px;height:50px;float:right;"></div> 
</footer>
 
  <div style="border:2px solid none;width:48px;height:0px;float:right;">    </div>
</article>
<?php endforeach; ?>


   </div>
</main>




<script>
    
    function funs(){
       a=$('#keyword').val();

   url='<?php echo url("sousuo"); ?>?key='+a;        

     window.location.href=url;

    }
    
    </script>
    
</body>
</html>
