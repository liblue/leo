<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:78:"D:\0000000\phpStudy\WWW\test\public/../application/index\view\index\index.html";i:1515572366;s:80:"D:\0000000\phpStudy\WWW\test\public/../application/index\view\public\header.html";i:1515664460;s:78:"D:\0000000\phpStudy\WWW\test\public/../application/index\view\public\foot.html";i:1515662962;}*/ ?>

   
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
<meta charset="UTF-8"><meta name="theme-color" content="#ccc">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>leo博客</title>
<link type="text/css" rel="stylesheet" href="__ROOT__/static/index/css/style.css">
<link type="text/css" rel="stylesheet" href="__ROOT__/static/index/layui/css/layui.css">
      <script  src="__ROOT__/static/index/js/jquery.min.js"/>  </script>
          <script  src="__ROOT__/static/index/layui/layui.js"/>  </script>
</head>
<body>

<div class="side">
<div class="overlay"><a href="" class="toc-btn iconfont icon-liebiao itip ifixed" id="art_dir" ></a></div>
<header class="content"  style="height:90%;padding-top: 30px">
      <nav>
	<ul>
		<li>   <a href="<?php echo url('/'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe68e;</i></span></a>
                    <a href="<?php echo url('message'); ?>" ><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;"  >&#xe63a;</i></span></a>
                    
                      <a href="<?php echo url('sousuo'); ?>"> <span class="iconfont icon-biaoqian itip ifixed" id="tags" > <i class="layui-icon" style="font-size: 30px; color: gray;">&#xe615;</i> </span> </a>
                    <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a>
		</li>
	</ul>
</nav>
    

    <nav>
        
	<ul>
            
         
		<li><a href="<?php echo url('message'); ?>" ><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;"  >&#xe611;</i></span></a>
                    
                      <a href="<?php echo url('sousuo'); ?>"> <span class="iconfont icon-biaoqian itip ifixed" id="tags" > <i class="layui-icon" style="font-size: 30px; color: gray;">&#xe615;</i> </span> </a>
	     <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a>
                    <a href="<?php echo url('link'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe64d;</i></span></a>
		</li>
	</ul>
</nav>
    
    
   
    <div  style="width: 100%;height:40%;padding-top:50px" >
       



    </div>

         
              <p>万头攒动火树银花之处不必找我。如欲相见，我在各种悲喜交集处。
</p>
            <p  style="float:right">——木心</p>

       </header>     
<footer> 
        	 
        <hgroup><h1>
                <a href="javascript:clickme();" class="itip ifixed" id="logofont" >&nbsp;I&nbsp;AM&nbsp; A &nbsp;LEO</a>
        
    </h1>


</hgroup>
<a href="<?php echo url('/'); ?>">
	<img class="avatar itip ifixed" id="logoicon" src="__ROOT__/static/index/img/shouye1.jpg" 
	/>
</a>
<!--
    <div><a href="{/}" target="_blank" style="font-size:14px;">About Me </a></div>
        <a href="{/}" target="_blank" style="font-size:14px;"><img src="__ROOT__/static/index/img/git.jpeg"  width="40px" height="30px"></a>-->

</footer>
</div>
        
    
    <main>
    
        <?php foreach($data as $v): ?>
<article>
 <div style="border:2px solid #88acdb;width:50px;height:0px"></div>    
 <div style="border:2px solid #88acdb;width:0px;height:48px"></div>  
<header  style="margin-top:-40px">
    
   
	<h2>
            <a rel="bookmark" href="<?php echo url('content','id='.$v['id']); ?>"><?php echo $v['title']; ?></a>
	</h2>

</header>
    <section class="abstract">
        <!--        <p><?php echo $v['content']; ?></p>
<p>2017-10-20 更新：<a href="https://zixizixi.cn/articles/2017/01/17/1484633274661.html#b3_solo_h4_11">7-5. 网络安全</a>：百度云高危漏洞预警</p>-->
        
        
<p><?php echo date("Y-m-d",$v['date']); ?> &nbsp;&nbsp;<a href="<?php echo url('content','id='.$v['id']); ?>"><?php echo $v['content']; ?></a></p>
    </section>
<footer class="tags"  >
	<!--<a  href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a>-->
        <a class="tag" rel="tag"  style="height: 25px;line-height:25px" href="/"><?php echo date("Y-m-d",$v['date']); ?></a>
	<a class="tag" rel="tag" href="<?php echo url('sousuo','cate=1'); ?>">开发</a>
	<a class="tag" rel="tag" href="">分享</a>
	

<!--           <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe62a;</i></span></a>
	 <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a>
		     <a href="<?php echo url('record'); ?>"><span class="iconfont icon-biaoqian itip ifixed" id="tags" ><i class="layui-icon" style="font-size: 30px; color: gray;">&#xe642;</i></span></a> -->
                     
                    <a href="<?php echo url('record'); ?>" style="margin-left:50%" ><span class="iconfont icon-biaoqian itip ifixed" id="tags">兰尼斯特兰尼斯兰尼斯特兰尼斯特</span></a> 
                    <a href="<?php echo url('record'); ?>" style="margin-right:10px" ><span class="iconfont icon-biaoqian itip ifixed" id="tags"   >-----兰尼斯特</span></a> 
 <div style="border:2px solid #88acdb;width:0px;height:50px;float:right;margin-bottom:52px"></div> 
</footer>
 
  <div style="border:2px solid #88acdb;width:50px;height:0px;float:right;margin-bottom:52px">    </div>
</article>
<?php endforeach; ?>

<nav class="pagination">
            
 <?php $__FOR_START_3293__=1;$__FOR_END_3293__=$num+1;for($i=$__FOR_START_3293__;$i < $__FOR_END_3293__;$i+=1){ if($i == $currentPage): ?>
<span class=" page-num"><?php echo $i; ?></span>


<?php else: ?> 
<a class="current page-num" href="/?page=<?php echo $i; ?>"><?php echo $i; ?></a>

<?php endif; } ?>


  </nav>


<footer class="footer">

</footer>







</main>

    
<div class="back" >
 
</div>
<!--      <div class="right five" >
        <a href="<?php echo url('write'); ?>" >  <i class="layui-icon" > &#xe612; </i>  </a>
</div>-->
<!--        <div class="right one" >  <div class="site-demo-button" id="layerDemo" style="margin-bottom: 0;">
                <button data-method="notice" class="layui-btn">示范一个公告层</button>
            </div>
        <a href="<?php echo url('write'); ?>" onclick="return fun()">  <img src="__ROOT__/static/index/img/write_art.jpg"> </a>
</div>-->
     <div class="right one" >  <div class="site-demo-button" id="layerDemo" style="margin-bottom: 0;">
               
        <button data-method="notice"  style="border: none;background-color:#efefef"> <img src="__ROOT__/static/index/img/write_art.jpg"></button> 
            </div>
</div>
        <div class="right two" >
            <div class="site-demo-button" id="layerDemo1" style="margin-bottom: 0;">
               
        <button data-method="notice"  style="border: none;background-color:#efefef"><i class="layui-icon" >&#xe614;</i></button> 
            </div>
          <!--<a href="<?php echo url('set'); ?>"></a>-->
</div>
        <div class="right three" >
        <a href="">  <i class="layui-icon"  onclick="turnOn()">&#xe6fc;</i>  </a>
</div>
<!--        <div class="right four" >
        <a href="">  <i class="layui-icon"  id="music">&#xe619;</i>  </a>
</div>-->
<!--          <div class="right four" >
              <a href="">  <img src="__ROOT__/static/index/img/shouye1.jpg">  </a>
</div>   -->
        <!--<i class="layui-icon" >&#xe651;</i>-->  

<script>
    function turnOn(){
        
           alert('现在打开你的网易云');
        
    }
    
    </script>
    
       <script>
  
//       function fun(){
//      layui.use('layer', function(){ //独立版的layer无需执行这一句
//      layer.open({
//        type: 1
//        ,title: false //不显示标题栏
//        ,closeBtn:true
//        ,area: '300px;'
//        ,shade: 0.8
//        ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
//        ,btn: ['确定留言', '算了吧']
//        ,btnAlign: 'c'
//        ,moveType: 0 //拖拽模式，0或者1
//        ,content: '<div style="padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;"><textarea placeholder="从这里开始写。。。" id="message" style="width:170px;height:300px;background-color:#393D49;border: none;resize : none;"></textarea> </div>'
//      });
//        });
//        retrurn true;
//    }
//</script>

<script>
    
    
    
layui.use('layer', function(){ //独立版的layer无需执行这一句
    
      $('#layerDemo1').on('click', function(){
      layer.open({
        type: 1
        ,title: false //不显示标题栏
        ,closeBtn: false
        ,area: '300px;'
        ,shade: 0.8
        ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
     
        ,btnAlign: 'c'
        ,moveType: 1 //拖拽模式，0或者1
        ,content: '<div style="padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;" >\n\
<input type="password" id= "password" style="font-size:26px;width:170px;height:100px;background-color:#393D49;border: none;resize : none;" placeholder="******">\n\
</div>\n\
<div style="  background-color:white;height:50px" style="align:center">   <button class="layui-btn layui-btn-normal" style="margin-left:40%;" onclick="  check(2)" >验证密码</button></div>'
  
      });
  });
  $('#layerDemo').on('click', function(){
      layer.open({
        type: 1
        ,title: false //不显示标题栏
        ,closeBtn: false
        ,area: '300px;'
        ,shade: 0.8
        ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
     
        ,btnAlign: 'c'
        ,moveType: 1 //拖拽模式，0或者1
        ,content: '<div style="padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;" >\n\
<input type="password" id= "password" style="font-size:26px;width:170px;height:100px;background-color:#393D49;border: none;resize : none;" placeholder="******">\n\
</div>\n\
<div style="  background-color:white;height:50px" style="align:center">   <button class="layui-btn layui-btn-normal" style="margin-left:40%;" onclick="  check(1)" >验证密码</button></div>'
  
      });
  });
  
});


function check(id){
    var password=$("#password").val();
   
         $.ajax({    
                    type:"post",    
                    url:"<?php echo url('login'); ?>",    
                    data:{password:password},//这里data传递过去的是序列化以后的字符串    
                    success:function(data){    
                        
                        if(data){
   layer.closeAll(); 
   if(id==1){
   window.location.href="<?php echo url('write'); ?>";}
   else{
        window.location.href="<?php echo url('set'); ?>";
   }
   
   
                        }
                        else{
                           layer.msg('密码错误', {icon: 1});
                          
                        }
                    }    
                }); 
               layer.closeAll(); 
}
</script>

</body>
</html>
  