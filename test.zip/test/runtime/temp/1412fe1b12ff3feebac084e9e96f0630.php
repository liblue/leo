<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"D:\0000000\phpStudy\WWW\test\public/../application/home\view\index\index.html";i:1514886656;}*/ ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta property="qc:admins" content="2554576230602773526375" />
    <meta name="baidu-site-verification" content="81BLZ1C2Te" />
    <!-- 百度验证  -->
    <meta name="baidu-site-verification" content="23p76Y9LU3" />
    <!--360验证-->
    <meta name="360-site-verification" content="1247af3cd890cf522c64a0188211dfba" />
    <!--神马平台验证-->
    <meta name="shenma-site-verification" content="6ddf919e460df88fe12310e2097a23cc_1497866600" />
    <title>欢乐书客官网_贼新贼全的综漫小说阅读网，火影小说，海贼小说，动漫小说，动漫同人</title>
    <meta name="keywords" content="综漫小说，动漫小说，火影小说，海贼小说，动漫同人"/>
    <meta name="description" content="欢乐书客提供最新好看的全本二次元穿越，娘化百合，各种萌化后宫小说在线阅读，综漫小说，动漫小说，火影小说，海贼小说，动漫同人"/>
    <!--<link rel="shortcut icon" type="image/x-icon" href=""/>-->
    <link rel="shortcut icon" href="https://www.hbooker.com/resources/image/icon/HappyBooker_Icon_32_R.png">

    <link rel="stylesheet" type="text/css" href='https://www.hbooker.com/resources/css/style.css'/>
    <!--<link rel="stylesheet" type="text/css" href=''/>-->
    <link rel="stylesheet" type="text/css" href='https://www.hbooker.com/resources/css/response.css'/>
        <!--<script type="text/javascript" language="javascript" src=''></script>-->
    <script type="text/javascript" language="javascript" src='https://www.hbooker.com/resources/scripts/bootstrap/js/jquery.js'></script>
        <script type="text/javascript">
        var HB = HB || {};
        HB.config = {jsPath:'https://www.hbooker.com/resources/js', rootPath:'https://www.hbooker.com/'};
        HB.book = {book_id: "", chapter_id: "", up_reader_id: "", is_paid: 0};
        HB.userinfo = {reader_id: 0,tel_num: '',license: '',redis_license: '', reader_name: '""', avatar_thumb_url: '""', vip_lv: ""};
        HB.urlinfo ={redirect:'https://www.hbooker.com/reader/modify_mobile?redirect=https%3A%2F%2Fwww.hbooker.com%2F'};        
    </script>
    <script type="text/javascript" src="https://www.hbooker.com/resources/js/initResponse.js"></script>
    <script type="text/javascript" src="https://www.hbooker.com/resources/js/base.js"></script>
    <script type="text/javascript" src="https://www.hbooker.com/resources/js/artDialog/6.0.4/dialog-min.js"></script>

    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?e843afdff94820d69cd6d82d24b9647e";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>
    <script>
		(function(para) {
		  var p = para.sdk_url, n = para.name, w = window, d = document, s = 'script',x = null,y = null;
		  w['sensorsDataAnalytic201505'] = n;
		  w[n] = w[n] || function(a) {return function() {(w[n]._q = w[n]._q || []).push([a, arguments]);}};
		  var ifs = ['track','quick','register','registerPage','registerOnce','clearAllRegister','trackSignup', 'trackAbtest', 'setProfile','setOnceProfile','appendProfile', 'incrementProfile', 'deleteProfile', 'unsetProfile', 'identify','login','logout','trackLink','clearAllRegister','getAppStatus'];
		  for (var i = 0; i < ifs.length; i++) {
		    w[n][ifs[i]] = w[n].call(null, ifs[i]);
		  }
		  if (!w[n]._t) {
		    x = d.createElement(s), y = d.getElementsByTagName(s)[0];
		    x.async = 1;
		    x.src = p;
		    x.setAttribute('charset','UTF-8');
		    y.parentNode.insertBefore(x, y);
		    w[n].para = para;
		  }
		})({
		  sdk_url: 'https://www.hbooker.com/resources/js/sensorsdata/sensorsdata.min.js',
		  name: 'sa',
		  web_url: 'https://sensorsdata.hbooker.com:4006/?project=production',
		  server_url: 'https://sensorsdata.hbooker.com:4006/sa?project=production',
		  heatmap:{}
		});
		sa.quick('autoTrack');
	</script>
</head>
<body>
    <!--360自动收录JS代码-->
<script>
(function(){
   var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?44f4bf97f937474731f263b201e00cf2":"https://jspassport.ssl.qhimg.com/11.0.1.js?44f4bf97f937474731f263b201e00cf2";
   document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script>
 <!-- 当前是章节阅读页 -->
 <!-- 当前是漫画阅读页 -->
<div id="bdstat" style="display: none"></div>

<div class="nav-top">
    <div class="ly-wrap">
        <ul class="login-info ly-fl">
                           <!--  <li><a class="wb" href="#" rel="nofollow"></a></li> -->
<!--                <li><a class="qq" href="#" rel="nofollow"></a></li>-->
                <li><a class="qq" href="https://www.hbooker.com/signup/qqlogin?redirect=https%3A%2F%2Fwww.hbooker.com%2F" rel="nofollow"></a></li>
				<!--<li><a class="weixin" href="https://www.hbooker.com/signup/weixin_login" rel="nofollow"></a></li> -->
                <li><a href="https://www.hbooker.com/signup/login?redirect=https%3A%2F%2Fwww.hbooker.com%2F" rel="nofollow">登录</a></li>
                <li class="line">|</li>
                <li><a href="https://www.hbooker.com/signup/register?redirect=https%3A%2F%2Fwww.hbooker.com%2F" rel="nofollow">注册</a></li>
                    </ul>
        <div class="nav-top-right ly-fr">
            <ul class="special ly-fl clearfix">
                <li class="recharge"><a href="https://www.hbooker.com/recharge/index"><i></i>充值中心</a></li>
                <li class="line">|</li>
                <li class="author"><a href="http://author-new.hbooker.com" target="_blank"><i></i>作者后台</a></li>
                <li class="line">|</li>
            </ul>
            <a class="app-download ly-fl" href="http://app.hbooker.com" target="_blank"><img src="" alt=""/></a>
            <div class="qr-code ly-fl">
                <a id="J_QrCode" href="javascript:;"><div><p>扫码下载客户端</p></div></a>
            </div>
        </div>
    </div>
</div>

<!--  欢迎每日登录 领取推荐票 -->
<div class="dialogLoginBox" id="J_DialogLoginBox" style="display: none;">
    <h3 class="title">欢迎每日登录</h3>
    <div class="cnt">
        <p>  你好~~</p>
        <p>送你 <span>
			0		</span> 张推荐票哦~</p>
        <p class="tips">登陆欢乐书客APP，<br/>完成每日签到任务，更有欢乐币相送。</p>
        <p>么么哒~~</p>
    </div>
    <div class="opt">
        <!--        <a class="btn-gettuijian" href="javascript:;" id="J_GetTJTicket">领取推荐票</a>-->
        <p class="auto-close"><i id="J_Timer">3</i>s后关闭</p>
    </div>
</div><div class="header">
    <div class="ly-wrap header-inner">
        <div class="ly-fl">
            <div class="logo">
                <h1><a href="https://www.hbooker.com/index"><img src="https://www.hbooker.com/resources/images/logo.png" alt="logo"></a></h1>
                <div>让阅读更精彩，让写作更简单 \^o^/</div>
            </div>
        </div>
    </div>

    <div class="menu-wrap" id="J_MenuFixed">
        <div class="ly-wrap menu-inner">
            <ul class="menu ly-fl clearfix">
                <li><a href="https://www.hbooker.com/" class='selected'>首页</a></li>
                <li><a href="https://www.hbooker.com/rank-index" >排行</a></li>
                <li><a href="https://www.hbooker.com/index-zhaiwen" >宅文</a></li>
                <li><a href="https://www.hbooker.com/index-tongren" >同人</a></li>
                <!--<li><a href="https://www.hbooker.com/index/header_cate_list/male" >男生</a></li>-->
                <li><a href="https://www.hbooker.com/index-female" >女生</a></li>
                <li><a href="https://www.hbooker.com/index-comic" >漫画</a></li>
                <li><a href="https://www.hbooker.com/index-game" >游戏</a></li>
                <li><a href="https://www.hbooker.com/book_list" >书库</a></li>
                <li><a href="https://www.hbooker.com/bbs" >社区</a></li>
            </ul>
            <div class="ly-fr">
                <form  name="myform"  target="_blank" class="search-form" >
                    <input name="keyword" autocomplete='off' type="text"  placeholder="搜索更多作品或作者" >
                    <button type="submit"></button>
                </form>
            </div>
        </div>
        <b></b>
    </div>
    </div><!--container start-->
<div class="container">
    <div class="ly-wrap">

        <div class="ly-main">
            
            <div class="first-col">
                <div class="banner banner-top J_Slider ly-fl">
                    <a href="javascript:;" class="slider-btn prev"></a>
                    <a href="javascript:;" class="slider-btn next"></a>
                    <ul>
                                                                                <li>
                                <a href="https://www.hbooker.com/activity/year_end_sec" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229045820974.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/year_end_sec" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/activity/comment_sec" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229095603438.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/comment_sec" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/book/booklist_detail?list_id=4416" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229015458946.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/book/booklist_detail?list_id=4416" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/activity/zhengwen_dec" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171222033912689.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/zhengwen_dec" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171115095550417.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="https://www.hbooker.com/activity/yuanchuang" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20170901100447582.png" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="https://www.hbooker.com/activity/yuanchuang" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="http://www.hbooker.com/book/100001126" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229023404588.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="http://www.hbooker.com/book/100001126" target="_blank">
                                                东方结庐人                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="http://www.hbooker.com/book/100055589" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229023430427.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="http://www.hbooker.com/book/100055589" target="_blank">
                                                氪金大佬的人理拯救之路                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="http://www.hbooker.com/book/100048520" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229023452846.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="http://www.hbooker.com/book/100048520" target="_blank">
                                                作家爱丽丝的猎魔手记                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                        <li>
                                <a href="http://app.hbooker.com/setting/event?item=tonggao_tz&noticeid=53" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171205033229566.jpg" alt="">
                                    <div class="banner-tit">
                                        <div class="banner-bg"></div>
                                        <p>
                                            <a href="http://app.hbooker.com/setting/event?item=tonggao_tz&noticeid=53" target="_blank">
                                                                                            </a>
                                        </p>
                                    </div>
                                </a>
                            </li>
                                                                        </ul>
                </div>
                <ul class="topic ly-fl" id="J_Topic">
                                                                    <li>
                            <a href="http://www.hbooker.com/book/100037552" target="_blank">
                                <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024605410.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【Mr星尘】</div>
                                    <div class="n">当吾入梦之际，即是梦魇开始之时。
其实这只是一个行走在无限世界中旅行顺带搞事情的故事。
列如：在WOW埋下Waaaagh的种子顺带中忽悠传播哲学；魔改掉ReC300英雄系列混战；F/A魔改21骑英灵使命召唤现代战争；
——“搞事情，我要搞事情！”by-夏诺
PS（1）新书求支持；
PS（2）已经有一本完结的一百五十万字的小说《那年那些穿越者》，作者节操是有保证的，请相信作者的节操。</div>
                                    <div class="num">7452人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="http://www.hbooker.com/book/100050516" target="_blank">
                                <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024620766.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【会飞的云】</div>
                                    <div class="n">s级女武神八重樱在某只无良小玉的“帮助”下来到了以幻想乡为主体的世界。
    我八重樱今天就要暴打你们全部，哪怕变成萝莉又如何，吾乃嘴强王者
     为了回到崩坏世界继续和卡莲完成某些不可描述的事情，幼樱走向了成为ex级女武神的道路（群号:622154697【众神眷恋的幻想乡】欢迎大大们前来指教哦！）</div>
                                    <div class="num">5548人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="http://www.hbooker.com/book/100041257" target="_blank">
                                <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024636156.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【卖萌的孔子】</div>
                                    <div class="n">高冷弱暖妹与干物病娇姐之间的，温！馨！日！常！</div>
                                    <div class="num">2932人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="http://www.hbooker.com/book/100051332" target="_blank">
                                <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024655924.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【坑王之王】</div>
                                    <div class="n">文艺版：于无限的世界之中，舞出钢铁之华尔兹。
通俗版：这是一个小职员，在无限的世界之中不断穿越，用出人意料的方式完成各种任务，扭转各种剧情的有趣的故事，咱的口号就是‘美特斯邦威，不走寻常路’。
企鹅群号码：417357299。</div>
                                    <div class="num">1663人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="http://www.hbooker.com/book/100054493" target="_blank">
                                <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024713873.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【月下美人】</div>
                                    <div class="n">高坂惠还是加藤惠？无关紧要。
问题是这个姐控的妹妹高坂桐乃该怎么办啊？算了，无视她好了。
还有我的青梅竹马为什么变成了英梨梨？还好，反正也是个败犬。
至于雪之下雪乃绝对正确？啧，高二病一个而已。
什么？我还有一个未婚妻叫万里花？拜托我也是女生好吗…
而且这个动不动就黑化的绫濑也很麻烦啊…
不过没关系，谁让我是圣人惠呢？</div>
                                    <div class="num">3026人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                <li>
                            <a href="http://www.hbooker.com/book/100031172" target="_blank">
                                <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024730535.jpg" alt="">
                                <div class="mask"></div>
                                <div class="info">
                                    <div class="t">【沙罗双树】</div>
                                    <div class="n">“长夜将至，我从今开始守望，至死方休。”
  这是845年玛利亚之墙被突破后，一个守夜人的征途。
书友群：117032150</div>
                                    <div class="num">4969人在看<i></i></div>
                                </div>
                            </a>
                        </li>
                                                            </ul>
            </div>

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>宅文推荐</h3>
                        <i class="line"></i>
                        <span>200位宅文大神鼎力打造</span>
                        <a href="http://www.hbooker.com/index/header_cate_list/zhaiwen">查看全部 ></a>
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list3 J_BookList">
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100046943" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171125/25-11-17095028-54617-100046943.jpg" alt="驱魔人信条">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/660069/avatar/thumb_8971d36e393760331d1a042847ad4ecc.jpg" alt="">【猫熊】</div>
                                        <div class="n">我们能够沐浴在光明之下，是因为有人驱散了即将降临的黑暗。或许在你我看不到的地方，他们仍在战斗。“我苏禹，是真实猛男，不是驱魔人的公关部经理！”“咳，挥拳头之前还是要先讲讲道理的嘛。他们要是不听话，你再揍他们也不迟啊。”“冷静点，你天天打来打去，我们快赔不起修理费了！”我生命中最痛苦的时刻，是我意识到世界上不可能有超级英雄的那一瞬间。假如现实不容许这份想象的存在，那就让我用笔把它写下来。请回到中学二年级，与我一同幻想、狂想、妄想。男人至死都应当是少年。欢迎加入驱魔人总部·黑曜之门，群号码：683614903</div>
                                        <div class="num">3548<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100046943" title="驱魔人信条" target="_blank">驱魔人信条</a></div>
                                <div class="info"><span>68.0万</span>︱<span>超现实都市</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100054510" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171213/13-12-17164640-27556.jpg" alt="开局一猫娘，没钱买猫粮">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【橘猪】</div>
                                        <div class="n">什么，你竟然想日猫？孙贼，放开那只猫，让我来！一只有破产光环的猫娘为何引起众人争夺？美丽少女为何把持不住？合法萝莉叫嚣着要加入？几百岁的俏寡妇也蠢蠢欲动？连神灵都要插足？是道德的沦丧还是猫娘太过诱人？受访者橘子为何含着泪说吸猫上瘾？欢迎收看本期大型节目，养猫人橘子的自述：开局一猫娘，买不起猫粮。（作者有节操，每天最少二更。途中有部分百合情节，部分。）</div>
                                        <div class="num">822<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100054510" title="开局一猫娘，没钱买猫粮" target="_blank">开局一猫娘，没钱买猫粮</a></div>
                                <div class="info"><span>13.0万</span>︱<span>异界幻想</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100054586" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171226/26-12-17235529-50426-100054586.jpg" alt="爱丽丝小姐的探索之旅">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/20149/avatar/thumb_2337fa7cbad0274ffa334aaa110cbc21.jpg" alt="">【盾猫】</div>
                                        <div class="n">来一次愉快的决斗吧</div>
                                        <div class="num">105<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100054586" title="爱丽丝小姐的探索之旅" target="_blank">爱丽丝小姐的探索之旅</a></div>
                                <div class="info"><span>1.8万</span>︱<span>异界幻想</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100049812" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171115/15-11-17120941-52738.jpg" alt="集结之命运">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-06/360143/avatar/thumb_020330492195a7021156c1a78fe72350.jpg" alt="">【全知全能猫】</div>
                                        <div class="n">在遥远遥远的未来，黑星和他罪恶的军队为了控制整个地球而发动了战争。他们唯一的对手是科学家詹姆斯·查格尔博士和他的精锐勇士。他们在一起，是不可战胜的。他们在一起，就是麦克瑞一号！</div>
                                        <div class="num">618<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100049812" title="集结之命运" target="_blank">集结之命运</a></div>
                                <div class="info"><span>7.0万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100051132" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171226/26-12-17213005-61592-100051132.jpg" alt="元首小姐的无限之旅">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【贝利尔】</div>
                                        <div class="n">主神2.33：莉莎·希特〇，汝因为将来犯下的‘反人类罪’，‘战争罪’，‘种族灭绝罪’，‘非法穿越罪’，数罪并罚，被判体感时间一万两千五百二十四年的有期徒刑。如果不想坐牢的话，就乖乖为主神空间打工吧(*￣︿￣)莉莎·希特〇小姐：喂喂喂，我可是生在新中华，长在红旗下的四有好青年，穿来德意志是为了建设皿煮富强的苏维埃德意志，你凭什么抓我……你根本不是我认识的主神！(╯‵□′)╯︵┻━┻第一副本：Fate/Zero，鱼唇的死人们，见识一下现代武器的威力吧第二副本（预定）：魔法少女小圆第三副本（预定）：魔禁and超炮第四副本（预定）：舰r以后还有撸撸羞什么的……最终目标，打死主神2.33，君临时管局，拯救德意志！！！作者的大纲很全，请诸君放心观看，绝对不会TJ┓( ´∀` )┏</div>
                                        <div class="num">1851<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100051132" title="元首小姐的无限之旅" target="_blank">元首小姐的无限之旅</a></div>
                                <div class="info"><span>30.9万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100050860" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171124/24-11-17142621-52469.jpg" alt="八重樱的穿越有点怪">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/792191/avatar/thumb_2ae2307b7a3f874f6fb9774dd18e965e.jpg" alt="">【女娲大小姐】</div>
                                        <div class="n">先说好，不是变身，主角就是八重樱本人。妾身毕竟写了近300万字的百合文(飞卢《时崎狂三的综漫之旅》)，写百合还是很稳得，各位快打卡上车。</div>
                                        <div class="num">2211<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100050860" title="八重樱的穿越有点怪" target="_blank">八重樱的穿越有点怪</a></div>
                                <div class="info"><span>36.9万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100049140" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171204/04-12-17181251-84629-100049140.jpg" alt="关于姐姐们不准我写妹控小说这件事情">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【傲娇的诚哥】</div>
                                        <div class="n">作为一个重度妹控，林一觉得有必要把妹控发扬光大。霞之丘诗羽：弟弟君，你对我的新作品：弟弟和我的那些年怎么看？林一：诗羽大姐，不如你看看我的作品：腹黑妹妹控兄记如何？英梨梨：林一，我最近画了一个姐姐和弟弟的同人作品，你看了给我说一下感想。林一：英梨梨姐姐，你有画妹妹和哥哥的同人作品吗？夏川真凉：小弟弟，最近，我的感觉怪怪的。林一：哎？最近，我的妹妹感觉怪怪的？林一看了眼周围的姐姐们，叹了口气：如果，有妹妹就好了</div>
                                        <div class="num">1090<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100049140" title="关于姐姐们不准我写妹控小说这件事情" target="_blank">关于姐姐们不准我写妹控小说这件事情</a></div>
                                <div class="info"><span>13.2万</span>︱<span>同人</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100054762" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171214/14-12-17202540-68288.jpg" alt="提督与舰娘们的休闲日常">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【夜晚的七星】</div>
                                        <div class="n">“这个月联合战果又破万了啊”提督看着大淀递来的战果表感叹道，在柱岛这个圣僧遍地走，方丈哪都有的地方，郭添安安静静的当条咸鱼，岂不美哉？</div>
                                        <div class="num">352<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100054762" title="提督与舰娘们的休闲日常" target="_blank">提督与舰娘们的休闲日常</a></div>
                                <div class="info"><span>5.6万</span>︱<span>同人</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100054302" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171212/12-12-17172442-14219.jpg" alt="学园都市之冰临">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【冷星之殇】</div>
                                        <div class="n">前世以A级异能者被封为华夏守护者的林夕，在一次任务中意外身亡。却因祸得福，得到冰神传承并穿越到了学园都市。在学园都市内，林夕又会有怎样的故事。“冰心破碎，是危险也是机会，小子，能不能更进一步就看你自己了”</div>
                                        <div class="num">313<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100054302" title="学园都市之冰临" target="_blank">学园都市之冰临</a></div>
                                <div class="info"><span>5.6万</span>︱<span>同人</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100044182" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170902/02-09-17224651-39291.jpg" alt="风吹草地见幽香">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-07/520796/avatar/thumb_a554e37057d54407bbc6c8255321b47f.jpeg" alt="">【风见幽狼】</div>
                                        <div class="n">以下纯属无聊口胡：东方幻想乡？盖亚？什么东东？算了，我还是晒晒太阳算了。幽香你别拔我身上的毛了成不？姑且是创了一个群561559120有兴趣就来吧</div>
                                        <div class="num">1166<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100044182" title="风吹草地见幽香" target="_blank">风吹草地见幽香</a></div>
                                <div class="info"><span>36.7万</span>︱<span>同人</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100050559" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171130/30-11-17201904-55847-100050559.jpg" alt="地狱火升职记">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-09/116124/avatar/thumb_b6b91ce519a2256ecf5fd930e3d2c511.jpg" alt="">【寻忆念】</div>
                                        <div class="n">“箱庭的男人们，拿起你们的武器！吾乃篡日者，吞噬太阳之魔王，来鼓起勇气打倒我，不要躲在女人后面瑟瑟发抖，像群懦夫一样让女人和孩子来面对我！”“洛斯里克的人类，火焰的传承不是不死人的职责，若只能期待着英雄的拯救，你们将只会是一群躲在大鸟羽翼下嗷嗷待哺的鹌鹑！吾乃不朽的火焰薪王，追随我，直面深渊！”......一只地狱火如是说道。【动漫穿越，剧情难免魔改，设定也为剧情服务，原著党请勿要过分深究】</div>
                                        <div class="num">3107<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100050559" title="地狱火升职记" target="_blank">地狱火升职记</a></div>
                                <div class="info"><span>55.7万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100051627" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171130/30-11-17092110-73372.jpg" alt="穿越蒂法的无限之旅">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-f.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/433803/avatar/thumb_be9d0a8186cb611472350dc7e9320e2f.jpg" alt="">【炼金风子】</div>
                                        <div class="n">变身成蒂法，穿越于各个单机游戏世界中求生。在刺客信条中与暗影共舞，在求生之路中直面尸山血海，在帝国时代中接受剑与火的洗礼，在古墓丽影中揭秘尘封的神话……当耳熟能详的游戏世界成为生存的战场，要如何才能回到熟悉的日常？【1月开始双更，更新时间为中午12点、晚上8点】</div>
                                        <div class="num">746<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100051627" title="穿越蒂法的无限之旅" target="_blank">穿越蒂法的无限之旅</a></div>
                                <div class="info"><span>10.4万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100047775" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171203/03-12-17001356-59025-100047775.jpg" alt="勇者变成女孩后回到地球成为宅">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/1749243/avatar/thumb_4868de89906b93bc4e5857b5968cbe74.jpg" alt="">【红鲤大魔王】</div>
                                        <div class="n">（前面几章对百合党来说可能有些诡异，不喜欢可以调至第六章后……）凌白穿越到异世界，成为了勇者打败了魔王，但是没想到最后被残留一口气的魔王诅咒了，变成了妹子，之后又回到了地球的故事。本作以现代地球和多个异世界为展开进行舞台，主角为大学生，摄入的元素有【异世，妖怪，异能，修真，魔法，炼金，穿越，外星人】等等，当然还会有一些动漫元素。喜欢的话麻烦点个收藏。唔……收藏很重要，收藏很重要，收藏很重要（重要的事情要说三遍）作者为社畜，尽量保持2天一更，周末的话可能会鸽（更新速度就要看读者老爷们的崔更是否勤快了）</div>
                                        <div class="num">3340<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100047775" title="勇者变成女孩后回到地球成为宅" target="_blank">勇者变成女孩后回到地球成为宅</a></div>
                                <div class="info"><span>65.8万</span>︱<span>青春日常</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100048641" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171107/07-11-17220657-98789-100048641.jpg" alt="拯救世界没有基本法">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-02/159855/avatar/thumb_b3ef36ef225a1bfaa565083964383696.jpg" alt="">【我恨我失踪的账号】</div>
                                        <div class="n">我们的目标只有一个，拯救世界。拯救世界，没有基本法。</div>
                                        <div class="num">2746<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100048641" title="拯救世界没有基本法" target="_blank">拯救世界没有基本法</a></div>
                                <div class="info"><span>53.5万</span>︱<span>游戏世界</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100049263" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171214/14-12-17211055-24081-100049263.jpg" alt="病娇姐姐好可怕">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/2434815/avatar/thumb_0ca64bf1781069b27141e06c6fc50e9a.jpg" alt="">【五月十六】</div>
                                        <div class="n">“如果把弟弟分成一块块保存在身边，这样弟弟君就不会再让姐姐伤心了......”</div>
                                        <div class="num">2257<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100049263" title="病娇姐姐好可怕" target="_blank">病娇姐姐好可怕</a></div>
                                <div class="info"><span>44.6万</span>︱<span>未来幻想</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100047545" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171211/11-12-17233445-29920-100047545.jpg" alt="请不要攻略我">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【菇菇菇菇奶奶】</div>
                                        <div class="n">霞之丘诗羽：“宁河君，请和我恋爱吧！”五河琴里：“欧尼酱，我们会永远在一起的对吧！”南小鸟：“前辈，能陪我一会吗？”……………………一觉起来，宁河发现这个熟悉的世界好像有些不一样了。请你们不要攻略我！书友群：248605801让我们交流一些关于小姐姐的事情吧！</div>
                                        <div class="num">6282<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100047545" title="请不要攻略我" target="_blank">请不要攻略我</a></div>
                                <div class="info"><span>109.8万</span>︱<span>青春日常</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100051153" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171220/20-12-17102053-44725-100051153.jpg" alt="我的妹妹居然是魔法少女">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【白羽小五】</div>
                                        <div class="n">“我的名字是卫宫士郎，卫宫家的长子，三天前收到了一封来自十年前的邮件。”“你的妹妹伊莉雅是魔法少女！”“很好笑对吧，肯定是某人的恶作剧，但是我完全笑不出来！”目前暂定的世界：魔伊、FSN、FA、FZ、魔法少女奈叶（滑稽）大纲的话有四千字了吧框架是有了应该不会改了大概（谁知道呢）穿梭于五个世界之间世界的破坏者Emiya......(拍走)</div>
                                        <div class="num">1971<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100051153" title="我的妹妹居然是魔法少女" target="_blank">我的妹妹居然是魔法少女</a></div>
                                <div class="info"><span>40.4万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                        <li>
                                <a class="img" href="http://www.hbooker.com/book/100046364" target="_blank">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171009/09-10-17091326-98859-100046364.jpg" alt="大唐西域直播记">
                                    <div class="mask"></div>
                                    <div class="info">
                                        <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-f.png" data-original="" alt="">【塞壬的港湾】</div>
                                        <div class="n">就是穿越了，怎么招吧？反正公路片都是B级片，小成本小制作……而且说不定还是邪典呢？是吧？师父？怎么着看都比“AmericanGods”安全吧？“Areyousure?”——by某腹黑的双马尾======身处海外无法实名验证上不了某论坛的港湾嘿咻嘿咻搬家中~弹幕和书评才是更新的动力~~</div>
                                        <div class="num">11152<i></i></div>
                                    </div>
                                                                    </a>
                                <div class="title"><a href="http://www.hbooker.com/book/100046364" title="大唐西域直播记" target="_blank">大唐西域直播记</a></div>
                                <div class="info"><span>177.7万</span>︱<span>动漫穿越</span></div>
                            </li>
                                                    </ul>
                    </div>
                
            </div>
            <!--mod-box end-->

            <!--banner start-->
            <div class="banner banner-main ly-mt30 J_Slider" data-type="ads">
                <ul>
                                                                        <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100050463">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024405941.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100050264">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024456874.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100047734">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024311356.jpg" alt="">
                                </a>
                            </li>
                                                            </ul>
            </div>
            <!--banner end-->

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>同人推荐</h3>
                        <i class="line"></i>
                        <span>万人在线抢着看</span>
                        <a href="http://www.hbooker.com/index/header_cate_list/tongren">查看全部 ></a>
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list3 J_BookList">
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100054327" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171213/13-12-17085652-94267-100054327.jpg" alt="身为妖怪的我却要陪阴阳师退治妖怪">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-02/1448521/avatar/thumb_f210ca7ed2cb3728c39a30152d1e64e3.jpg" alt="">【百忍菌】</div>
                                            <div class="n">京都，自古以来便是妖怪的聚集之地，据传占领了京都便会成为魑魅魍魉之主。千年前，一只来自华夏的妖怪率领着百鬼夜行镇压了所有妖怪，成为了平安时代的夜之统治者。而在千年之后。“本座可是魑魅魍魉之主，为什么要陪阴阳师退治妖怪呀。”随手解决掉那些作乱的妖怪之后，白夜感叹了一声，满脸唏嘘。而身旁的阴阳师少女则咬牙切齿地瞪着他，最后从牙缝里挤出几个字。“明明就是你强行要动手的，我又没让你帮忙！”“哎呀哎呀，小丫头果然麻烦。”</div>
                                            <div class="num">521<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100054327" title="身为妖怪的我却要陪阴阳师退治妖怪" target="_blank">身为妖怪的我却要陪阴阳师退治妖怪</a></div>
                                    <div class="info"><span>7.8万</span>︱<span>超现实都市</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100046302" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171211/11-12-17192546-64458-100046302.jpg" alt="龙族之黑王">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【Y吧是家】</div>
                                            <div class="n">青春，热血，叛逆，孤独，这是龙族的世界。有欢声笑语，坎坷曲折，血与泪，爱与恨。“不管你曾经被伤害得有多深，我会一直在你身边的，谁都可能背叛你，但是我，永远爱着你！”一个简单的拥抱，路明非与路鸣泽。“哥哥，我们的火，会把整个世界都点燃。”......</div>
                                            <div class="num">569<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100046302" title="龙族之黑王" target="_blank">龙族之黑王</a></div>
                                    <div class="info"><span>9.0万</span>︱<span>超现实都市</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100032674" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171120/20-11-17123357-77437-100032674.jpg" alt="火焰将熄">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img/133633/avatar/thumb_8bf3406ac854dad1c5c7d24a968053b1.jpg" alt="">【moye】</div>
                                            <div class="n">神明陨落，火焰将熄，整个罗德兰即将为野心与鲜血吞噬，黑暗的末世已然到来。为了改写悲惨的命运，薪火的余烬被送往了混乱开初之时，踏上了火焰传承的道路。一切的故事，由此开始。书群号426766012觅隐之亭，欢迎书友加入</div>
                                            <div class="num">6250<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100032674" title="火焰将熄" target="_blank">火焰将熄</a></div>
                                    <div class="info"><span>195.2万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100029128" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171202/02-12-17231351-47692-100029128.jpg" alt="船长的次元开拓手记">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-06/164510/avatar/thumb_1304dc6fb5a2d7806c8d671e30037eae.jpg" alt="">【三人塔】</div>
                                            <div class="n">辛苦十几年首付买船即将踏上人生巅峰的利斯特先生不幸穿越了“所以，这就是你拐骗无知少女上船的理由？”“这是雇佣！我好好给她们开工资了！”“这些话在局子里再说吧。”新大陆的开拓者不小心变成了新次元的开拓者，要怎样做才能装作自己经常穿越的样子，在线等挺急的！</div>
                                            <div class="num">16136<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100029128" title="船长的次元开拓手记" target="_blank">船长的次元开拓手记</a></div>
                                    <div class="info"><span>620.4万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100049193" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171107/07-11-17181614-35248.jpg" alt="薪王的救世之旅">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/2102229/avatar/thumb_9d65181aad09eaed2371f8bc52d5a504.jpg" alt="">【夙夜】</div>
                                            <div class="n">作为一个父母双亡，有车有房，一辈子不愁吃喝的二次元宅，穿越就已经够倒霉的了，何况还是穿越到了黑魂的世界！好吧，就算中二已经毕业，叶铭也还是要说“这个世界，由我来拯救！”费尽千辛万苦成了薪王，结果你告诉我这根本毫无意义？！“我燃烧灵魂来支撑这个世界，你却告诉我这个世界已经不可能再出现下一个具有薪王资格的人了？”这不是坑爹吗！于是，为了这个世界，也为了自己，新任的薪王大人踏上了在多元宇宙中寻找挽救初火的方法的旅程第一卷：从零开始的异世界生活进行中</div>
                                            <div class="num">1201<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100049193" title="薪王的救世之旅" target="_blank">薪王的救世之旅</a></div>
                                    <div class="info"><span>23.0万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100051105" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171220/20-12-17162313-60657-100051105.jpg" alt="超现实公会的次元开拓之旅">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【小宇大魔王】</div>
                                            <div class="n">（ps：前二十五章节奏有点毒，咸鱼没有这么多时间改了）-------------------------------------------------------------这是一个搞笑玩梗救世文，讲述的是某个天朝穿越者成为虚空生物的救世日常（scp，希灵，以及一些奇奇怪怪的世界）。</div>
                                            <div class="num">638<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100051105" title="超现实公会的次元开拓之旅" target="_blank">超现实公会的次元开拓之旅</a></div>
                                    <div class="info"><span>11.2万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100049203" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171107/07-11-17203604-83342.jpg" alt="沉迷观察怪兽娘的我当了二五仔">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/81185/avatar/thumb_b146d414b13fb40270c550999eb0bc47.jpg" alt="">【小陆喵】</div>
                                            <div class="n">亚波人：“来，给大家介绍一下，老娘手下的最强打手！艾斯基拉！”“一个十字架敲晕炎头！”“斯匹修姆光线，艾美力姆光线，M87光线样样精通！”“泡了数十头怪兽娘，别人还以为他给我扣了十几顶绿帽子！”艾斯基拉：“不！我不是！我没有！我就是一位很正直的怪兽观察员而已！”</div>
                                            <div class="num">1154<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100049203" title="沉迷观察怪兽娘的我当了二五仔" target="_blank">沉迷观察怪兽娘的我当了二五仔</a></div>
                                    <div class="info"><span>20.1万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100001897" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c160624/24-06-16224332-9943-100001897.jpg" alt="这些年与那些年的幻想乡">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/81185/avatar/thumb_b146d414b13fb40270c550999eb0bc47.jpg" alt="">【小陆喵】</div>
                                            <div class="n">“永琳永琳？”“怎么了公主殿下？”银发医师将爱人的脖子枕到了大腿上，歪了歪头道“......你们两个又公然撒狗粮，火鸡上烧了他们！”大和抚子的气质瞬间消失，蓬莱山辉夜发出了类似败犬的哀鸣“你丫才是火鸡！！！【凤翼天翔】”然后银发的魔神从妻子大腿上抬起了头，看见了月之公主消失在了火焰之中后轻轻伸出了自己的手，将一面金色的屏障立在了两人的身前拦住了那来势汹汹的熊熊烈焰【光子力屏障】今天的幻想乡也很和平呢~</div>
                                            <div class="num">7248<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100001897" title="这些年与那些年的幻想乡" target="_blank">这些年与那些年的幻想乡</a></div>
                                    <div class="info"><span>216.8万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100029193" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170309/09-03-17114923-71427-100029193.jpg" alt="麻将少女之南风物语正传">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-f.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-07/291426/avatar/thumb_e94f214211b2cfc17cce8eede06cfaec.jpg" alt="">【笛音】</div>
                                            <div class="n">本文是天才麻将少女的同人文。这是重生的南浦数绘，在经历过一次大起大落之后，从国三开始，在高中活跃的新的麻雀物语。本书要说有什么特别的地方话......作者自己的麻将打得还算不错这点算吗？233333。——“就算是为了自己，我也不会放弃麻将！”啊，对了，本文百合向。这是很重要的。再一个，不拆CP也不搞NTR。</div>
                                            <div class="num">592<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100029193" title="麻将少女之南风物语正传" target="_blank">麻将少女之南风物语正传</a></div>
                                    <div class="info"><span>15.7万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100000677" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c151127/27-11-15113158-70229.jpg" alt="一本好看的神奇宝贝同人">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2016-12/38650/avatar/thumb_7f7ce599495d208e2a346a131cb19157.jpg" alt="">【爱武小兵】</div>
                                            <div class="n">这两天突然觉得……可以说是良心发现，觉得这样子下去这本书真不是事……一个月就两更，一年就二十四更。这样子想完本真的得到天荒地老了……新开的三国貌似也不冷不热的，所以就想要不然先专心把这书搞定了？各位书友，咱们打个商量吧。这本书是同人，是没有订阅的，想有点收入就要进推荐榜前十。因此我的方案是这样子的：从即日起，每200推荐票、10月票或1000打赏就折合额外更新一章，每月封顶按月份计28到29章不等，二月算26、27章。咱不要你们每天都推荐，反正满200就算一章加更，加上原本的两更，只要大家投票，日更也是可以做到的。总之大家支持下，我也努力下，咱们一起努力把这书尽快完本吧！加更条件如下：每50张月票或5000打赏就再额外加更一章，这个就不搞什么封顶了，不过我最多只能做到一天双更就是了……书友群群号：298603024</div>
                                            <div class="num">13908<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100000677" title="一本好看的神奇宝贝同人" target="_blank">一本好看的神奇宝贝同人</a></div>
                                    <div class="info"><span>509.3万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100050470" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171209/09-12-17225322-28724-100050470.jpg" alt="路人吕布的青春物语">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/356697/avatar/thumb_fd74ddcf621042e6f906bcd4573d4577.png" alt="">【公山先生】</div>
                                            <div class="n">吕布重生到了现代，这还不是最坑的最坑的是，他这辈子的爹是个超级‘段正淳’，处处留情。我妹妹有春日野穹、雪之下雪乃、加藤惠，姐姐有冬马和纱，你是要让我唱‘你究竟有几个好妹妹’吗？还有很多？不是吧!等等，我养了只猫，它不会变身吧。qq群：161670436</div>
                                            <div class="num">662<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100050470" title="路人吕布的青春物语" target="_blank">路人吕布的青春物语</a></div>
                                    <div class="info"><span>14.9万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100050255" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171204/04-12-17144156-32720-100050255.jpg" alt="一拳轰出世界和平">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-04/335742/avatar/thumb_e7d36add363972b7fa8cb2bc36c7248f.jpg" alt="">【路過的中二少年】</div>
                                            <div class="n">（非正统一拳流，伪无敌向，单女主）（本书聊天群：651587286～一起来聊天冲人气吧～）魔女，一拳打爆。英灵，一拳打爆。妖怪，一拳打爆。超能力者，一拳打爆。魔法少女，一拳打……等等，这打爆了对小朋友的教育不好，还是打晕吧。想当魔术师的偶像妹妹，一拳……下不了手，还是扛回家好好教育一下，好好的学园偶像不做当什么魔术师啊！——到了最后，他一拳轰出了世界和平，世间皆称诵着他的名讳。他既不秃头，也不无敌，他只是一名挥舞着拳头的肌肉猛男。他是南大辅，今天，依然在锻炼和妹控的路上，奔走不息。▲△▲可儿那由多：“说到大辅哥，大家的第一印象会是什么啊？”刑部姬：“肌肉。”巴麻美：“肌肉。”南小鸟：“肌肉呢。”南大辅：“嗯？为什么不是猛男？”众人：“因为你的肌肉太显眼了啊！”</div>
                                            <div class="num">699<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100050255" title="一拳轰出世界和平" target="_blank">一拳轰出世界和平</a></div>
                                    <div class="info"><span>12.6万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100046094" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170929/29-09-17221644-79387-100046094.jpg" alt="我家干物妹总是被穿越">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/280784/avatar/thumb_e5f3fed173cec3a010ee3d31abfeab46.jpg" alt="">【醉久】</div>
                                            <div class="n">土间太平和土间埋，过着平淡而快乐的日常兄妹互动。但最近小埋开始变的奇怪了。不仅张口闭口称妾身，游戏的口味也越来越重，黄油开始光明正大的走起，最后还开始反抗他哥哥！！！所以！正直的，绝对非妹控的土间太平决定和妹妹在夜黑风高的夜晚，开始一场“友好”的人生相谈。ps：看了b站某视频突然心有感触决定写写。ps：每天固定两更保底吧！</div>
                                            <div class="num">5816<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100046094" title="我家干物妹总是被穿越" target="_blank">我家干物妹总是被穿越</a></div>
                                    <div class="info"><span>149.4万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100045605" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170928/28-09-17112737-92275-100045605.jpg" alt="我的二次元很有问题">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-11/1415972/avatar/thumb_9851b6d2ffb177c12ec9eacb83733ebf.jpg" alt="">【我姐是幽香】</div>
                                            <div class="n">穿越成高坂京介，有了一个叫作高坂桐乃的妹妹，本以为从此可以过上平静的日常。却不想穿越第一天，就在成绩优秀，相貌美丽的妹妹身上发现了一盒受到诅咒的录相带。同年级的轻小说畅销作家霞之丘诗羽，更是突然间踮着脚尖来上学。而且青梅竹马换成了富江是闹哪样？</div>
                                            <div class="num">12572<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100045605" title="我的二次元很有问题" target="_blank">我的二次元很有问题</a></div>
                                    <div class="info"><span>602.9万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100025268" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171014/14-10-17172121-71987-100025268.jpg" alt="我为女儿〇一秒">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-02/1368264/avatar/thumb_194315d50e3643bbfcda01421b346792.jpg" alt="">【吾有八宗罪】</div>
                                            <div class="n">“爸爸，如果你不趁现在攻略妈妈，我就会因为历史改变而消失！”本来以为注定孤独一生的吴申，一天醒来眼前却接二连三的出现自称来自未来的女儿们！我怎么就喜当爹了呢？蛤，我说你们还是另请高明。什么？你说你妈妈叫霞之丘诗羽？你说你妈咪是椎名真白？你说你母亲叫雪之下雪乃？你老妈是八云紫？于是为了拯救自己可爱的萝莉女儿们，吴申踏上了浩浩荡荡的攻略之旅。书友群：370725794欢迎加入(/≧▽≦)/求月票求推荐票求打赏~~~</div>
                                            <div class="num">65562<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100025268" title="我为女儿〇一秒" target="_blank">我为女儿〇一秒</a></div>
                                    <div class="info"><span>7,266.1万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100027692" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170215/15-02-17161009-47399.jpg" alt="我的脑中有个好感度系统">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-02/1300016/avatar/thumb_a7c2293bfeaecda2231197e27f87c9ad.jpg" alt="">【土见凛】</div>
                                            <div class="n">意外穿越人生再次重启，而且来到了一个貌似是二次元的世界，并且一不小心就得到了一个烂大街的金手指我的人生终于要喜闻乐见的登上巅峰了吗？咦，有些不对啊，为什么别人的金手指那么厉害，我的这个金手指那么废柴啊，连系统精灵什么的都没有等等，好像不对哦，好感度提升到满值之后居然有福利…………</div>
                                            <div class="num">38759<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100027692" title="我的脑中有个好感度系统" target="_blank">我的脑中有个好感度系统</a></div>
                                    <div class="info"><span>1,430.6万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100053599" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171226/26-12-17113321-66143-100053599.jpg" alt="我，纣王，百合">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-09/2175659/avatar/thumb_2e9e61e072b0e6bd2f24ca0100b0310c.jpg" alt="">【冷浮屠】</div>
                                            <div class="n">本书是百合文，原名《什么？隔壁超市皮肤半价？》穿越游戏《封神》大火特火，女主也成为游戏中的妲己，奉命诱惑同样穿越进游戏的美女——纣王。与此同时，哪吒，姜子牙，杨戬，姬发接连被穿越，整个游戏世界逐渐成为了现代玩家的另一个战场。游戏的主线任务早早揭开，即：顺应武王伐纣，但是隐藏任务却也同时出现：扶商灭周。到底是要选择纣王，还是要选择姬发？或者……在游戏中成立你自己的势力。选择不同，命运同样会改变？每个穿越人物都有不同的想法。于是，奇妙的历险就此开始。</div>
                                            <div class="num">379<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100053599" title="我，纣王，百合" target="_blank">我，纣王，百合</a></div>
                                    <div class="info"><span>6.2万</span>︱<span>战争历史</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100051923" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171215/15-12-17140256-46178-100051923.jpg" alt="高武男异世无双传">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【青椒虎皮肉】</div>
                                            <div class="n">高武位面，强者如云，有摘星捉月、翻山倒海之能，此世少年，穿越无限位面，去成就至强者之名！穿越位面：jojo冒险奇遇第一部（已完结）北斗神拳（进行中）拳皇96（即将开始）冰与火之歌（正在赶稿）jojo冒险奇遇二战魔改版（构思中……）</div>
                                            <div class="num">159<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100051923" title="高武男异世无双传" target="_blank">高武男异世无双传</a></div>
                                    <div class="info"><span>3.1万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->


            <!--banner start-->
            <div class="banner banner-main ly-mt30 J_Slider" data-type="ads">
                <ul>
                                                                        <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100046148">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024223645.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100013853">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024239289.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100039114">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024331766.jpg" alt="">
                                </a>
                            </li>
                                                            </ul>
            </div>
            <!--banner end-->

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>男生推荐</h3>
                        <i class="line"></i>
                        <span>万人在线抢着看</span>
                        <a href="http://www.hbooker.com/index/header_cate_list/male">查看全部 ></a>
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list2 J_BookList">
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100029012" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171204/04-12-17173015-10830-100029012.jpg" alt="苍蓝的战舰少女之现代战争">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img/129657/avatar/thumb_f4b59bde99da9a7f170ff6c0ef158bb9.jpg" alt="">【zyts新折翼】</div>
                                            <div class="n">新的旅程，新的开始。当各个已经消失或退役的战舰以舰灵或深海的方式出现在这个纷乱的，矛盾渐起的现代世界，又会发生什么情况。抽风的欧洲，血色太平洋，东欧巨变，苏联重铸，世界大战……总之，这是一个关于幼萌版海雾的和人类之间的故事。北宅：姐姐你在哪cv2:妹妹，我一定会把你救回来。平海，宁海：我们的海军梦，终于实现了深海萨拉托加：我讨厌人类</div>
                                            <div class="num">1338<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100029012" title="苍蓝的战舰少女之现代战争" target="_blank">苍蓝的战舰少女之现代战争</a></div>
                                    <div class="info"><span>50.0万</span>︱<span>未来幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100044043" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171120/20-11-17211637-95086-100044043.jpg" alt="樱战的百合">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-f.png" data-original="" alt="">【天下是樱】</div>
                                            <div class="n">有一天，那个叫做不知火流樱的妹纸醒来了，她发现全身被封禁起来，动弹不得，还好另一个也叫做樱的家伙闪着金光从天而降，衣服上写着书客二字，看着妹纸念念有词的说着听不懂的咒语，于是妹纸的冒险开始了，那是一场惊天动地的百合大战。</div>
                                            <div class="num">521<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100044043" title="樱战的百合" target="_blank">樱战的百合</a></div>
                                    <div class="info"><span>9.0万</span>︱<span>未来幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100047417" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171014/14-10-17155816-21410-100047417.jpg" alt="黑衣仓鼠">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-11/214465/avatar/thumb_6af3cd2c75a5d9b288cef25461afa695.jpg" alt="">【温侯高达】</div>
                                            <div class="n">人们总是对于安宁的生活习以为常，他们认定，地球是银河系中最为瑰丽的一颗明珠。然而在看似和平的环境之下，地球却接纳了大量的外来人口，而一直在暗中保护着地球的和平的，则是一支从不曾出现过也不会被人铭记的力量，黑超特警。“罗格哈斯，你因为涉嫌偷渡，盗用他人信息，抢劫，谋杀，恐怖袭击以及随地便溺等多项罪行，即将遭受法律的惩罚，你有什么要说的吗？！”“我抗议！别的罪名也就算了，随地大小便算什么罪名！就算你们是涉外局也不能这么随便栽赃陷害吧！”“得了吧，你们思帕森人的便溺物具有极高的腐蚀性，你小子就是用自己的排泄物腐蚀掉了银行防盗钢门才进去抢劫的，还以为我们不知道？你以为地球是什么你想来就来的地方？还是说，你想要和我的圣装泰格里斯讲讲物理？”身披红白黑三色金属甲壳的高大人形冷笑着举起了手里那杆有着繁复花纹的双管霰弹枪，黑洞洞的枪口带着危险的气息直指着对面的外星人。</div>
                                            <div class="num">1131<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100047417" title="黑衣仓鼠" target="_blank">黑衣仓鼠</a></div>
                                    <div class="info"><span>32.0万</span>︱<span>未来幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100050767" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171228/28-12-17203152-73090-100050767.jpg" alt="我的青春物语只有孤独">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/292080/avatar/thumb_af52b2421bd904d3e088e69ec7863037.jpg" alt="">【蓬羽伊文】</div>
                                            <div class="n">“对我来说，生活是什么？”“孤独。不是亲情，也不是爱情，是孤身一人单独走在路上，承担着名为自我的责任。”“人，只能依靠自己”</div>
                                            <div class="num">3720<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100050767" title="我的青春物语只有孤独" target="_blank">我的青春物语只有孤独</a></div>
                                    <div class="info"><span>55.5万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100032429" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170502/02-05-17134429-33633-100032429.jpg" alt="迦勒底工作人员日记">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-07/41040/avatar/thumb_1ce8a9b81f2e42db2c7e064abd8e2be6.jpg" alt="">【幕后黑爪】</div>
                                            <div class="n">一名普通迦勒底员工眼中的人理修复之旅。名为迦勒底的，与特异点无关的种种日常。</div>
                                            <div class="num">11494<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100032429" title="迦勒底工作人员日记" target="_blank">迦勒底工作人员日记</a></div>
                                    <div class="info"><span>785.4万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100027358" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170611/11-06-17223133-48148-100027358.jpg" alt="剑客立于音乃木坂">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-05/197603/avatar/thumb_880ba44c6e9beae0e0d9b871d6f06680.jpg" alt="">【轩辕龙夜】</div>
                                            <div class="n">只要我还站在她们的面前，我就不会让任何人伤害到她们！！By-剑羽这是属于我们的奇迹，属于我们的故事，但......为什么你不在了？By-μ's不.....从头到尾，我就不属于奇迹By·剑羽《金光布袋戏》和《lovelive》的混合型世界观，奇迹正在萌芽</div>
                                            <div class="num">1354<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100027358" title="剑客立于音乃木坂" target="_blank">剑客立于音乃木坂</a></div>
                                    <div class="info"><span>47.0万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100050866" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171205/05-12-17165226-66251-100050866.jpg" alt="JOJO的无限冒险">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【醋溜阳春面】</div>
                                            <div class="n">主神：“本年度的最佳轮回者获奖者是——焦杰！！！”主神：“下面有请我们拳打型月、脚踢猎人、纵横钢炼、笑傲黑魂的焦杰上台讲话。”焦杰：“咳，关于这个讲话，其实我没什么好说的，我本可以讲说无可奉告，但你们又不满意，那我只能教给你们一点人生的经验——我们替身使者是真的可以为所欲为。”（有人反馈说前几章没啥意思，可以跳着看。）（每天稳定两更，一章早晨一章中午）（封面来源网络，侵删。）</div>
                                            <div class="num">1317<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100050866" title="JOJO的无限冒险" target="_blank">JOJO的无限冒险</a></div>
                                    <div class="info"><span>31.9万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100049873" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171115/15-11-17150617-10821.jpg" alt="配角的自我修养">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【缘定东方】</div>
                                            <div class="n">穿越进自己写的的小说。还是有着结局为败犬，全灭的BadEnd的小说。鲁树人表示，自己还是安安静静的当个配角好了。看着各个日常系主角的装逼日常。自己只想好好的过着普通的日常。只是，他好像忘了，操蛋的生活总是会把你拉回你不想进入的糟糕的轨道。（文抄公，后宫向，非百合变身，无娘化，治愈系，非正常系日常文，主角非印刷机，主漫画）</div>
                                            <div class="num">361<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100049873" title="配角的自我修养" target="_blank">配角的自我修养</a></div>
                                    <div class="info"><span>6.4万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100049005" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171105/05-11-17152633-10023.jpg" alt="从黑魂归来的废柴们">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-03/1566629/avatar/thumb_3899b597bd825e47e05bb623a14def0b.jpg" alt="">【皓北】</div>
                                            <div class="n">又名《当废柴从黑魂归来后决定开无双》《论入侵与反入侵》《当把那些让人恨铁不成钢的主角扔去传火之后》讲述废柴们进入黑魂受苦之后衣锦还乡的故事。简介：萌新菜月昴：萌新卡在法兰遗迹，还有个叫间桐雁夜的紫灵疯狂入侵我，各位大佬们救命！巨剑猛男生驹：莫怕，前面那堆篝火边有我白符，召唤我。太阳gay佬塔兹米：白符旁，我金符，速摸。法兰尬舞队队员路明非：什么？有个萌新在法兰？等我先换上法兰守卫誓约，狼血与我同在！入侵狂人间桐雁夜：默默戴上积累者誓约，掏出血红眼眸宝珠。推图大佬威廉：别怕，等我打烂盖尔狗头就去帮你虐杀那帮子...爷爷我错了！资深红灵哥布林杀手：戴上黄蜂弗林，从百夜优一郎菊花中拔出洛直，转身放拟态，深藏功与名，却迎面撞上警察。暗月疯子金木君：耳——朵——！！！........天野雪辉：我还被关在古老师的小黑屋里，谁来救救我(유∀유）</div>
                                            <div class="num">799<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100049005" title="从黑魂归来的废柴们" target="_blank">从黑魂归来的废柴们</a></div>
                                    <div class="info"><span>12.5万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100052582" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171204/04-12-17232207-6357-100052582.jpg" alt="食我召唤术">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/945805/avatar/thumb_77aa55c7dcf56b553baa7a728f37956d.jpg" alt="">【纯血萨哈拉】</div>
                                            <div class="n">一个面带爽朗笑容、长得不似黑人的黑皮肤男子问道：“你想穿越吗？”李亚伟爽快的回答道：“好啊！”论如何在系统的帮助下成为旧日支配者。………………求求各位投票啊！不然我让小绿咬你们哦！！！本人真·萌新，保证全文欢乐到底。</div>
                                            <div class="num">117<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100052582" title="食我召唤术" target="_blank">食我召唤术</a></div>
                                    <div class="info"><span>2.4万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100051876" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171229/29-12-17155905-91941-100051876.jpg" alt="论如何在一群魔女中保护贞操">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/38823/avatar/thumb_35afc0bf762f9427cd9b96a83db482f9.jpg" alt="">【赵四大】</div>
                                            <div class="n">什么？！我穿越了？好事啊！但是魔女是什么鬼？我明明是男的啊！难道不应该是魔男吗？！而且这群一开始就满好感的魔女小姐姐们是怎么回事？总觉得有点不好的预感。你说魔女族群中就只有我一个男性？.....对不起打扰了！！小姐姐们求放过！</div>
                                            <div class="num">575<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100051876" title="论如何在一群魔女中保护贞操" target="_blank">论如何在一群魔女中保护贞操</a></div>
                                    <div class="info"><span>9.8万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100051062" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171204/04-12-17125626-15590-100051062.jpg" alt="真是抱歉，好不容易觉醒的超能力却没什么用">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/2618642/avatar/thumb_29ba872130e0ebf79cad57962b6cfc5a.jpg" alt="">【寂灭血觋】</div>
                                            <div class="n">在6月9日上午10点23分12秒被称为“进化之时”的事件当中，全体的七十亿人类全部昏迷了2.14秒。等到他们醒来之后，人类全部拥有了超能力。但是可惜的是这些超能力却没有什么用，只是一堆莫名其妙的现象而已。在“进化之时”的三个月后，16岁的高中生陆平在家门口遇见了莫名其妙的少女：“我想要组建超能力战队来征服世界。请问你有兴趣吗？”少年完全莫名的超能力战斗物语就此开始！书友群：540978584</div>
                                            <div class="num">794<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100051062" title="真是抱歉，好不容易觉醒的超能力却没什么用" target="_blank">真是抱歉，好不容易觉醒的超能力却没什么用</a></div>
                                    <div class="info"><span>13.3万</span>︱<span>超现实都市</span></div>
                                </li>
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->


            <!--banner start-->
            <div class="banner banner-main ly-mt30 J_Slider" data-type="ads">
                <ul>
                                                                        <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100035470">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024424846.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100049348">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024256365.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100049823">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024441547.jpg" alt="">
                                </a>
                            </li>
                                                            </ul>
            </div>
            <!--banner end-->

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>女生推荐</h3>
                        <i class="line"></i>
                        <span>万人在线抢着看</span>
                        <a href="http://www.hbooker.com/index/header_cate_list/female">查看全部 ></a>
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list2 J_BookList">
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100030864" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170512/12-05-17151224-44907-100030864.jpg" alt="伪娘之二次元萌妹">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-f.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-05/1593178/avatar/thumb_b50f62942ddaa5bbabaf90dccdd3cc47.jpg" alt="">【梦幻3】</div>
                                            <div class="n">这是一只伪娘与众多二次元萌妹的欢乐搞笑日常的故事……ps1:本书慢热型，有一点变百剧情，大概不到三十章，届时大家不喜请跳过。Ps2:群号:636990229，答案:伪娘百合大法好。</div>
                                            <div class="num">2431<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100030864" title="伪娘之二次元萌妹" target="_blank">伪娘之二次元萌妹</a></div>
                                    <div class="info"><span>62.8万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100025156" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170208/08-02-17181652-54910-100025156.jpg" alt="才不是天才偶像少女">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2017-04/1360370/avatar/thumb_af8d621549e9fb4ae4fc06a7fab70542.jpg" alt="">【正义凛然】</div>
                                            <div class="n">苏梦穿越成了平行世界里一个12岁的小萝莉。并且得到了可以进入游戏世界学习角色技能的能力。影视、音乐、文学、游戏、动漫……粉丝们惊讶的发现，他们的小偶像好像什么都会。书友群：32879247</div>
                                            <div class="num">16293<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100025156" title="才不是天才偶像少女" target="_blank">才不是天才偶像少女</a></div>
                                    <div class="info"><span>992.6万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100048559" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171129/29-11-17130820-13345-100048559.jpg" alt="我的生活不可能是后宫GAME！">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【占扑者】</div>
                                            <div class="n">知道吗？有些时候，外挂只能是多余的东西......所谓的穿越到十年以后的异能力，除了能让自己明白十年之后的妻子是谁，疯狂的流失营养以外还能做到什么？什么？十年后的我大难临头？什么？十年后的我一无所有？什么？十年后的我成为了种马？这特么都什么鬼未来，我决定了，要改变这样的未来，创造幸福的人生！现在，开始改变——“我宁愿十年以后在一无所知的情况下被柴刀，也不愿意像这样，被全世界的亚人盯紧下面，我不是种马，不渴望sex，美女们，请自重！！！”——by·某个幸福结局当中的吕奉仙【请帮忙投一投推荐票，萝莉控在这里谢过了】【渴望ing】【希望喜欢本书的能进群看看萝莉控不定时发的福利种子，QQ群；527585381】</div>
                                            <div class="num">11048<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100048559" title="我的生活不可能是后宫GAME！" target="_blank">我的生活不可能是后宫GAME！</a></div>
                                    <div class="info"><span>281.8万</span>︱<span>青春日常</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100054682" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171214/14-12-17165301-41285.jpg" alt="我与巫女有个约会">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【乐观的在梦游】</div>
                                            <div class="n">阴与阳是世间万物运行的基础。正如有生必有死，有善必有与之相对立的恶，有人繁衍生息的地方必有妖魔邪祟，百鬼夜行。常言妖魔恶，怎知人心更毒似蛇蝎。幽冥极乐，魔度众生。当身负九尾天狐血脉的半妖邂逅了东瀛巫女，腹黑男遭遇暴力女，一个个灵异怪诞的事件袭来，究竟是人心更诡谲，还是鬼怪更恐怖？一副浮世画卷就此缓缓展开。其实这是一个温馨充满爱的故事。</div>
                                            <div class="num">1287<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100054682" title="我与巫女有个约会" target="_blank">我与巫女有个约会</a></div>
                                    <div class="info"><span>14.0万</span>︱<span>神秘未知</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100032928" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170523/23-05-17095747-12644-100032928.jpg" alt="v家：最后的亚种">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img/147557/avatar/thumb_46c629671e1a5405ebe08fba2fe45444.jpg" alt="">【止音】</div>
                                            <div class="n">你们有看到我家初音吗？非常可爱，就和小天使一样。她也没走丢也没怎么样，我就是觉得你们都该看一看。“不过要是动了歪心思，把你眼珠子都挖掉喔？”</div>
                                            <div class="num">233<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100032928" title="v家：最后的亚种" target="_blank">v家：最后的亚种</a></div>
                                    <div class="info"><span>6.5万</span>︱<span>同人</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100015641" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c160802/02-08-16131847-48511-100015641.jpg" alt="谁说少女不能用肉搏">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-f.png" data-original="https://avatar.kuangxiangit.com/novel/img_item/img-2016-12/124987/avatar/thumb_448f3e007817f1f7247f6e3f627a2c8f.jpg" alt="">【注定孤独终老】</div>
                                            <div class="n">就让我用这一双拳头，打破你的幻想吧！年轻漂亮的黑发少女举着粉拳一脸微笑的打碎了身旁的一颗巨石，顺便一挺胸，把另一边的大石用胸口砸的粉碎“姐……你能别这么野蛮吗，这是在破坏我好不容易塑造出来的形象啊”心里某个萌萌的声音无奈的说道。黑发少女脸一黑：“魏晓芸，我警告你，以后别再趁着我学习的时候，拿我的身体去调戏男人，要不然我就对你不客气。”不远处某个路人甲一脸崩溃的看着眼前清音柔体的少女一拳打烂的巨石，如同烂泥般瘫软在地瑟瑟发抖。（……我的姐姐为什么这么野蛮）（住嘴！）一体双魂的姐妹在这无尽的残酷世界相依为命（吊打土著）的故事PS：脑洞一开，立马就控制不住我记几了PS2：群号：597294476，欢迎给作者提建议，聊天（目前缺人中）</div>
                                            <div class="num">4591<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100015641" title="谁说少女不能用肉搏" target="_blank">谁说少女不能用肉搏</a></div>
                                    <div class="info"><span>141.2万</span>︱<span>神秘未知</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100052129" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171203/03-12-17202813-69524-100052129.jpg" alt="无限之黑翼">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【孤独的傻龙】</div>
                                            <div class="n">“吾名死亡之翼！天命之灭世者！万物的终结者！无可阻挡！无可违逆！吾既！大灾变！”身高不到一米二的黑发萝莉，并且有事没事就会装成智者一样说出故作玄虚的话。让人感觉她真可爱，同时又不得不相信她的话。谁叫这个萝莉曾是，黑龙之王，大地的守护者，死亡之翼，灭世者呢……</div>
                                            <div class="num">700<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100052129" title="无限之黑翼" target="_blank">无限之黑翼</a></div>
                                    <div class="info"><span>12.2万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100050709" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171206/06-12-17224711-54493-100050709.jpg" alt="关于我被神坑成2B之后">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-11/2462301/avatar/thumb_255222741538062d8855574d40e71a9b.jpg" alt="">【尤尔哈2B】</div>
                                            <div class="n">再强大的黑客也没办法控制被拔了电源的电脑，除非真得是神。所以说，当电脑上出现奇怪弹窗的时候，最好的方式就是拔掉电源来验明正身。不过很显然，如果主角这么做了，那就没这个故事了。这是一个普通游戏玩家被神用文字陷阱坑了之后，身体变成2B，然后在各个动漫世界搞事的故事。——————————日常一更，偶尔两更，嘛，就这样。</div>
                                            <div class="num">1517<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100050709" title="关于我被神坑成2B之后" target="_blank">关于我被神坑成2B之后</a></div>
                                    <div class="info"><span>30.8万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100048724" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171102/02-11-17102640-53959.jpg" alt="我不是御主也不是英灵">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/2539954/avatar/thumb_0344e030ff22bf2f424bc6bcd2a691ef.jpg" alt="">【阳子】</div>
                                            <div class="n">我不是御主，也不是英灵，但我想要圣杯。各怀心思的魔术师与英灵聚集在身边，不妨碍我继续这场漫长的旅行。朋友卡、搭档卡、好人卡，卡卡在手。它们是我的护身符，是我的保护色，是我吃瓜看戏的入场券。曾经，我相信她们柴刀的对象会一直是别人。后来，我发现自己还是太年轻了。</div>
                                            <div class="num">715<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100048724" title="我不是御主也不是英灵" target="_blank">我不是御主也不是英灵</a></div>
                                    <div class="info"><span>16.5万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100033839" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170514/14-05-17235526-14767-100033839.jpg" alt="姐姐总是被穿越">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2016-05/124570/avatar/thumb_182adb19bf25c97e24cac1a110dc94e2.jpg" alt="">【但慰青帝】</div>
                                            <div class="n">姬灵曦推开房门，就看到姐姐坐在床榻上，衣衫半解，俏目含春：“遵从召唤而来，你就是我的……”“我不是你的舰长、提督、马斯特、指挥官、营养师！更没有召唤你，请你快滚！不然打死！”对姬灵曦来说，这世上没有什么事，比姐姐总是被穿越更糟心了，这些自称【科学与魔法的最终人形热兵器】的穿越者把他的生活搞得一团糟，每个月购买钢铝油弹金棋子银棋子熔火核心等乱七八糟的东西就要花一大笔钱，但如果只是这样也就算了……什么？你们世界的女人露个后背大腿小蛮腰都不算伤风败俗的？什么？你们世界的舰娘战斗的时候，要把舰装的神经连接装置放在oo里？什么？你们世界的英灵必须要和马斯达补魔，才能发挥百分百的战斗力？娘希匹哦！你们这些荡妇！我们的世界是正经的仙侠世界啊！快给我滚回去！姐姐总是被穿越，我能怎么办？我也很绝望啊！</div>
                                            <div class="num">16758<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100033839" title="姐姐总是被穿越" target="_blank">姐姐总是被穿越</a></div>
                                    <div class="info"><span>728.8万</span>︱<span>未来幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100054624" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c180102/02-01-18094938-88890-100054624.jpg" alt="鬼母系统">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-01/1241889/avatar/thumb_3c8cf90c3aa03563065a86c3e9a46d0c.jpg" alt="">【脸是用来滚键盘】</div>
                                            <div class="n">不要被这个鬼畜的名字迷惑，其实这个故事还是纯爱的，嗯，应该是这样！为了保护女儿上刀山下火海在所不辞就算变成修罗恶鬼也要保护好女儿的好妈妈专用无敌系统1.0，简称鬼母系统（笑，想歪的自觉收藏投票哦~下海（1/3）外送小妹（1/1）</div>
                                            <div class="num">170<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100054624" title="鬼母系统" target="_blank">鬼母系统</a></div>
                                    <div class="info"><span>2.7万</span>︱<span>超现实都市</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100055601" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171219/19-12-17142712-74764-100055601.jpg" alt="变身galgame里的百合少女">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/2587692/avatar/thumb_3ac460c1c100105ba174f6e5ad869f53.jpg" alt="">【苏雪儿】</div>
                                            <div class="n">变身穿越的废萌主角苏雪儿仍一心只想着宅在家里混吃等死，可是有一天她却发现曾经攻略的galgame角色接二连三的出现在了面前。有不可思议的校园怪谈、有异次元的神秘生物、也有超现实奇幻魔法，这是一个由无数galgame交错而成的神秘世界。为了了解真相，慵懒颓废的苏雪儿恋恋不舍的走出了房门....</div>
                                            <div class="num">401<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100055601" title="变身galgame里的百合少女" target="_blank">变身galgame里的百合少女</a></div>
                                    <div class="info"><span>4.3万</span>︱<span>超现实都市</span></div>
                                </li>
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->

            <!--banner start-->
            <div class="banner banner-main ly-mt30 J_Slider" data-type="ads">
                <ul>
                                                                        <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100040797">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024348748.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100050220">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024512616.jpg" alt="">
                                </a>
                            </li>
                                                    <li>
                                <a target="_blank" href="http://www.hbooker.com/book/100021396">
                                    <img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_index_recommend/carousel/20171229024529526.jpg" alt="">
                                </a>
                            </li>
                                                            </ul>
            </div>
            <!--banner end-->

            <!--mod-box start-->
            <div class="mod-box ly-mt55">
                                    <div class="mod-tit">
                        <h3>BOSS任性推荐</h3>
                        <i class="line"></i>
                        <span>万人在线抢着看</span>
                        <a href="http://www.hbooker.com/book_list/">查看全部 ></a>
                    </div>
                    <div class="mod-body">
                        <ul class="book-list book-list1 J_BookList">
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100047531" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171106/06-11-17095804-39498-100047531.jpg" alt="退役救世主的我转职当老师">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【金刚葫芦妹】</div>
                                            <div class="n">本书又名《退役救世主的我转职当老湿》，《放开我的女学生们！男同学您请随意处置》职业救世主遍地走，强者多如狗的中枢世界，曾经号称如彗星般崛起的天才职业救世主邹昊，因为一些不可描述的原因毅然选择辞职，但氪金毫无节制的他氪光了所有积蓄，不得已只能被忽悠去天立救世主学院，成为了一名救世主导师……自称五千年才出一个的冰山美人院长，永远面无表情的黑长直学生会女会长，口嫌体正直的合法萝莉，经常会有大胆想法的纯情小太妹……以上种种统统跟我没有半毛钱关系，我是一个有职业操守的老师，麻烦请毕业后再来我的房间！PS：作者乃是绰号漂移之王的资深老司机，想要飘一把的同学请务必上车！</div>
                                            <div class="num">11759<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100047531" title="退役救世主的我转职当老师" target="_blank">退役救世主的我转职当老师</a></div>
                                    <div class="info"><span>372.7万</span>︱<span>异界幻想</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100046943" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171125/25-11-17095028-54617-100046943.jpg" alt="驱魔人信条">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-12/660069/avatar/thumb_8971d36e393760331d1a042847ad4ecc.jpg" alt="">【猫熊】</div>
                                            <div class="n">我们能够沐浴在光明之下，是因为有人驱散了即将降临的黑暗。或许在你我看不到的地方，他们仍在战斗。“我苏禹，是真实猛男，不是驱魔人的公关部经理！”“咳，挥拳头之前还是要先讲讲道理的嘛。他们要是不听话，你再揍他们也不迟啊。”“冷静点，你天天打来打去，我们快赔不起修理费了！”我生命中最痛苦的时刻，是我意识到世界上不可能有超级英雄的那一瞬间。假如现实不容许这份想象的存在，那就让我用笔把它写下来。请回到中学二年级，与我一同幻想、狂想、妄想。男人至死都应当是少年。欢迎加入驱魔人总部·黑曜之门，群号码：683614903</div>
                                            <div class="num">3548<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100046943" title="驱魔人信条" target="_blank">驱魔人信条</a></div>
                                    <div class="info"><span>68.0万</span>︱<span>超现实都市</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100044150" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170919/19-09-17235530-89767-100044150.jpg" alt="邂逅众星的我到底做错了什么？">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="https://avatar.kuangxiangit.com/novel/img-2017-09/1791155/avatar/thumb_15a4234149fcf9f42bdd5e328a61dc02.jpg" alt="">【黑兔白免】</div>
                                            <div class="n">无垠战火里唯有一个搀靠在尸海血涯中淋浴着余晖的『萌萝莉』注视荒芜的一切。哭不被允许，因为他已用祈祷映射代价，失去一切沦为兵器。心死，唯有『她』才能救赎。“所以说这就是你把我当成爸妈，姐兄，闺蜜，伴侣的理由吗？”看似萌萝莉的孩子看着与他几乎一个板子印出来的样子的幼女，无奈叹息道。不过终究为了你，我还是愿意毁灭世界，斩断自己的可能，为了让你赢得无数轮回的可能，在这尽头寻找，邂逅众星，为了你成为『容器』。——所以这TM不是后宫吗？套路！——抱歉，我只爱她一个！主角完全高虐，胃药无用，需救心丸，主角三无萌，三观正，无毒，不过10章7章打架，勿怪。妹控毁灭世界，剧情严重烧脑，观看前务必啃脑白金食用。</div>
                                            <div class="num">865<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100044150" title="邂逅众星的我到底做错了什么？" target="_blank">邂逅众星的我到底做错了什么？</a></div>
                                    <div class="info"><span>13.0万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100050715" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171122/22-11-17133214-81727-100050715.jpg" alt="我，高须大河，电击文库新人">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【高須大河】</div>
                                            <div class="n">我是一个萌新。嗯，没错。如同字面意义上的萌新。我曾在电击文库上连载过一本名为《西格斯塔的银发公主》的爆热轻小说，到现在为止是不是很正常?但是你告诉我!这个突然拿着剑准备砍了我的银发女生是谁?!谁tm把这个世界的设定给改变了啊！不可能是我吧？</div>
                                            <div class="num">275<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100050715" title="我，高须大河，电击文库新人" target="_blank">我，高须大河，电击文库新人</a></div>
                                    <div class="info"><span>2.4万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100043802" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171018/18-10-17151359-73794-100043802.jpg" alt="获得了系统的我不小心把女神掰弯了这件事">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【明月松间照】</div>
                                            <div class="n">我叫李然，是个有点中二的怂货高中生。暗恋着勉强算青梅竹马的女孩六年，却一直不敢向她告白，我以为这种情况会一直波澜不惊的持续下去。直到那一天，我得到了系统，然后……ps0：如果觉得本书还算有趣，前面又看不下去的话，可以尝试从十五章以后观看，如果再不行，好吧，请把它从你的书架取消吧！ps1：标签有变百，但不是纯百，所谓的不是纯百绝不是嫁人，再说一遍，绝不嫁人。ps2：开头没看到变百的书友，可以看一下书评区的长评。ps3：621218861欢迎各位书友进群，问题验证答案姓徐。</div>
                                            <div class="num">5807<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100043802" title="获得了系统的我不小心把女神掰弯了这件事" target="_blank">获得了系统的我不小心把女神掰弯了这件事</a></div>
                                    <div class="info"><span>188.3万</span>︱<span>超现实都市</span></div>
                                </li>
                                                            <li>
                                    <a class="img" href="http://www.hbooker.com/book/100056104" target="_blank">
                                        <img class="lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171222/22-12-17182942-52997.jpg" alt="无限之绝地求生">
                                        <div class="mask"></div>
                                        <div class="info">
                                            <div class="t"><img class="lazyload" src="http://www.hbooker.com/resources/images/avatar-default-m.png" data-original="" alt="">【咕货鸟】</div>
                                            <div class="n">因为一场意外，徐霖带着一身的外挂技能穿越了！他被强制参与一场真实的“吃鸡游戏”，以自己的狗命为赌注，去和另外99名参赛者搏杀。但就在他以为自己可以凭借一身“仙法”，轻轻松松的杀出重围时，他很快便发现，自己的对手貌似有点不太对劲儿……徐霖：谁来告诉我，对面那群“二次元COSER”是什么情况？我是不是摊上事儿了？</div>
                                            <div class="num">185<i></i></div>
                                        </div>
                                    </a>
                                    <div class="title"><a href="http://www.hbooker.com/book/100056104" title="无限之绝地求生" target="_blank">无限之绝地求生</a></div>
                                    <div class="info"><span>1.9万</span>︱<span>动漫穿越</span></div>
                                </li>
                                                    </ul>
                    </div>
                            </div>
            <!--mod-box end-->

            <!--mod-box start-->
                        <div class="mod-box ly-mt60">
                <div class="mod-tit1 ly-mr30">
					<h3><i></i>最近更新小说</h3>
                    <a class="ly-fr" href="http://www.hbooker.com/book_list" target="_blank">查看更多 &gt;</a>
                </div>

                <div class="mod-body">
                    <div class="book-list-table-wrap">
                        <table class="ly-mt30 book-list-table" width="100%">
                            <tr>
                                <th><span>序号</span></th>
                                <th><span>小说类别</span></th>
                                <th><span>小说书名/小说章节</span></th>
                                <th><span>字数</span></th>
                                <th><span>小说作者</span></th>
                                <th>更新时间</th>
                            </tr>
                                                                                                <tr>
                                        <td><p class="code center">1</p></td>
                                        <td><p class="type center">【超现实都市】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100048630" title="我，妹妹，兽娘，修罗场！" target="_blank">我，妹妹，兽娘，修罗场！</a><span>第124章 又是一个嘤嘤怪</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">265437</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2542275" target="_blank">侍星山</a></p></td>
                                        <td><p class="date center">2018-01-01 21:43:38</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">2</p></td>
                                        <td><p class="type center">【青春日常】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100049801" title="变身超级萝莉主播" target="_blank">变身超级萝莉主播</a><span>老子这条命是锅给的</span></p></td>
                                        <td><p class="num center">149804</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2167368" target="_blank">否知</a></p></td>
                                        <td><p class="date center">2018-01-02 17:35:17</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">3</p></td>
                                        <td><p class="type center">【超现实都市】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100050523" title="无聊神的无趣物语" target="_blank">无聊神的无趣物语</a><span>第51章：游戏（上）</span></p></td>
                                        <td><p class="num center">123960</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2445151" target="_blank">寂静十月</a></p></td>
                                        <td><p class="date center">2018-01-02 17:35:09</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">4</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100044908" title="本子无限" target="_blank">本子无限</a><span>10:秘书舰</span></p></td>
                                        <td><p class="num center">120361</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2206122" target="_blank">琉璃之花</a></p></td>
                                        <td><p class="date center">2018-01-02 17:34:46</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">5</p></td>
                                        <td><p class="type center">【同人】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100031506" title="东方龙鸣录" target="_blank">东方龙鸣录</a><span>鲜血舞曲·帷幕拉下 后日谈（上）——失却的巫女</span></p></td>
                                        <td><p class="num center">1159388</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/1661987" target="_blank">星落莲殿</a></p></td>
                                        <td><p class="date center">2018-01-02 17:32:32</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">6</p></td>
                                        <td><p class="type center">【异界幻想】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100043551" title="奥利维亚女公爵" target="_blank">奥利维亚女公爵</a><span>第九章 鏖战伊始</span></p></td>
                                        <td><p class="num center">17979</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/493306" target="_blank">月影蒙蒙</a></p></td>
                                        <td><p class="date center">2018-01-02 17:32:16</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">7</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100049769" title="基友是狐狸精" target="_blank">基友是狐狸精</a><span>第一百零三章 女人，我是你老公</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">227452</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2595520" target="_blank">学姐控</a></p></td>
                                        <td><p class="date center">2018-01-02 17:31:20</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">8</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100049645" title="魔法少女之祈愿的物语" target="_blank">魔法少女之祈愿的物语</a><span>第十章 回归的寄语</span></p></td>
                                        <td><p class="num center">151045</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/39940" target="_blank">早霜的酒柜</a></p></td>
                                        <td><p class="date center">2018-01-02 17:31:11</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">9</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100050060" title="我叫李舜生，请多指教" target="_blank">我叫李舜生，请多指教</a><span>第二更……看心情吧</span></p></td>
                                        <td><p class="num center">140000</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/66602" target="_blank">别致苏</a></p></td>
                                        <td><p class="date center">2018-01-02 17:31:05</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">10</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100051330" title="二次元的无敌旅行者" target="_blank">二次元的无敌旅行者</a><span>第四十四章  诱宵美九</span></p></td>
                                        <td><p class="num center">103409</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2089989" target="_blank">无节操</a></p></td>
                                        <td><p class="date center">2018-01-02 17:30:59</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">11</p></td>
                                        <td><p class="type center">【游戏世界】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100047301" title="时日曷丧之娜迦崛起" target="_blank">时日曷丧之娜迦崛起</a><span>。。。。。。。。。</span></p></td>
                                        <td><p class="num center">1271</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/1820171" target="_blank">泽瑞斯之影</a></p></td>
                                        <td><p class="date center">2018-01-02 17:30:34</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">12</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100056612" title="暗黑系主角随心所欲" target="_blank">暗黑系主角随心所欲</a><span>第七章：色字上头一把刀</span></p></td>
                                        <td><p class="num center">15334</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/1804888" target="_blank">荇枫</a></p></td>
                                        <td><p class="date center">2018-01-02 17:30:01</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">13</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100047642" title="我叫咕哒子" target="_blank">我叫咕哒子</a><span>第2章 两个定时炸弹</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">436460</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/513006" target="_blank">奈朵琉雅</a></p></td>
                                        <td><p class="date center">2018-01-02 17:30:01</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">14</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100044256" title="我们，卫宫一家，都是英灵" target="_blank">我们，卫宫一家，都是英灵</a><span>第二百二十三章 伊莉雅？！伊莉雅！</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">521493</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/1946086" target="_blank">银酱万年</a></p></td>
                                        <td><p class="date center">2018-01-02 17:30:01</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">15</p></td>
                                        <td><p class="type center">【异界幻想】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100043913" title="异界升级加点娘" target="_blank">异界升级加点娘</a><span>254开课啦（5）</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">523539</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/101470" target="_blank">灵乌路穹</a></p></td>
                                        <td><p class="date center">2018-01-02 17:30:01</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">16</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100035641" title="没救了，比企谷的英灵生活" target="_blank">没救了，比企谷的英灵生活</a><span>第六十五章   朿萩</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">476140</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/1891589" target="_blank">褶呆子</a></p></td>
                                        <td><p class="date center">2018-01-02 17:29:28</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">17</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100055324" title="一拳小樱" target="_blank">一拳小樱</a><span>第十二章 怪物们（二）</span></p></td>
                                        <td><p class="num center">33435</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2679262" target="_blank">游藏</a></p></td>
                                        <td><p class="date center">2018-01-02 17:29:25</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">18</p></td>
                                        <td><p class="type center">【异界幻想】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100056499" title="许愿方式错误的穿越" target="_blank">许愿方式错误的穿越</a><span>舌战学生会（中）</span></p></td>
                                        <td><p class="num center">34862</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/1558099" target="_blank">我穷是因为懒</a></p></td>
                                        <td><p class="date center">2018-01-02 17:28:07</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">19</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100049886" title="无限，王座之下" target="_blank">无限，王座之下</a><span>第96章 结算完成，返回主空间</span></p></td>
                                        <td><p class="num center">224890</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2478504" target="_blank">水晶公主</a></p></td>
                                        <td><p class="date center">2018-01-02 17:27:55</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">20</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100049888" title="名叫流龙马的我却开真实系" target="_blank">名叫流龙马的我却开真实系</a><span>65 你以为我是扎古？</span></p></td>
                                        <td><p class="num center">134711</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/775945" target="_blank">一星战神就是我</a></p></td>
                                        <td><p class="date center">2018-01-02 17:27:46</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">21</p></td>
                                        <td><p class="type center">【游戏世界】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100046111" title="为不美好的世界献上女装大佬" target="_blank">为不美好的世界献上女装大佬</a><span>74.异形大战终结者和碟中谍(上)</span></p></td>
                                        <td><p class="num center">230156</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/1636248" target="_blank">萝莉控的挽歌</a></p></td>
                                        <td><p class="date center">2018-01-02 17:25:38</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">22</p></td>
                                        <td><p class="type center">【未来幻想】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100050711" title="科洛尼亚风暴之旅" target="_blank">科洛尼亚风暴之旅</a><span>第四十六章 Solara</span></p></td>
                                        <td><p class="num center">337881</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2328845" target="_blank">SoonTM</a></p></td>
                                        <td><p class="date center">2018-01-02 17:25:33</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">23</p></td>
                                        <td><p class="type center">【青春日常】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100050048" title="双生情缘" target="_blank">双生情缘</a><span>第一百四十四章  鸿家</span></p></td>
                                        <td><p class="num center">868714</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2599901" target="_blank">千尾狐姬</a></p></td>
                                        <td><p class="date center">2018-01-02 17:24:37</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">24</p></td>
                                        <td><p class="type center">【同人】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100032257" title="晓的水平线之下" target="_blank">晓的水平线之下</a><span>零、提督到任</span></p></td>
                                        <td><p class="num center">730982</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/391854" target="_blank">梅鲁·伊萨卡</a></p></td>
                                        <td><p class="date center">2018-01-02 17:22:55</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">25</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100056896" title="来迦勒底当然是为了拯救人理" target="_blank">来迦勒底当然是为了拯救人理</a><span>第二章 这些凯尔特人真好认</span></p></td>
                                        <td><p class="num center">7609</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2788255" target="_blank">嘿嘿嘿嘿猫</a></p></td>
                                        <td><p class="date center">2018-01-02 17:22:54</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">26</p></td>
                                        <td><p class="type center">【青春日常】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100021984" title="我在霓虹传播精神食粮" target="_blank">我在霓虹传播精神食粮</a><span>第四十八章 《地铁2033》和软件分区</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">1233994</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/1080284" target="_blank">白</a></p></td>
                                        <td><p class="date center">2018-01-02 17:22:37</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">27</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100053241" title="妖仙犬夜叉" target="_blank">妖仙犬夜叉</a><span>第三十六章 村子</span></p></td>
                                        <td><p class="num center">78603</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/90080" target="_blank">月明and秋夜</a></p></td>
                                        <td><p class="date center">2018-01-02 17:22:24</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">28</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100053990" title="魔法少女晓月" target="_blank">魔法少女晓月</a><span>第十三章：见家长(雾)</span></p></td>
                                        <td><p class="num center">19172</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/2700367" target="_blank">天雷知己</a></p></td>
                                        <td><p class="date center">2018-01-02 17:21:31</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">29</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100030130" title="我的世界只有萝莉" target="_blank">我的世界只有萝莉</a><span>第51章 你们，是同一个人吗？</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">293364</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/473870" target="_blank">二小姐·芙兰朵露</a></p></td>
                                        <td><p class="date center">2018-01-02 17:20:01</p></td>
                                    </tr>
                                                                    <tr>
                                        <td><p class="code center">30</p></td>
                                        <td><p class="type center">【动漫穿越】</p></td>
                                        <td><p class="name"><a href="http://www.hbooker.com/book/100027164" title="无限血之哀" target="_blank">无限血之哀</a><span>第二十五章 尼德霍格提不起劲</span><i>[VIP]</i></p></td>
                                        <td><p class="num center">1276913</p></td>
                                        <td><p class="author center"><a href="http://www.hbooker.com/reader/33363" target="_blank">懂了</a></p></td>
                                        <td><p class="date center">2018-01-02 17:20:01</p></td>
                                    </tr>
                                                                                    </table>
                    </div>
                </div>
            </div>
                        <!--mod-box end-->
        </div>
        <div class="ly-side index-side">
            <!-- 公告 begin -->
            <div class="big-event">
                                                                                        <div><a href="https://www.hbooker.com/activity/zhengwen_nov" target="_blank"><img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="http://www.hbooker.com/resources/imagesactivity/zhengwen_nov_banner.jpg" alt="活动"></a></div>
                                                                                                <div><a href="http://www.hbooker.com/index/fuli" target="_blank"><img class="lazyload" src="http://www.hbooker.com/resources/images/transparent.png" data-original="https://avatar.kuangxiangit.com/novel/img_notice/20170601112204377.jpg" alt=""></a></div>
                                                                        </div>
            <!-- 公告 end -->
            <div class="recomm-tit ly-mt30">
                <h4>精选荣誉榜单</h4>
            </div>

                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">主编强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 精挑细选</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="http://www.hbooker.com/book/100048176" target="_blank">
                                <img class="img lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171026/26-10-17155454-15665-100048176.jpg" alt="">
                                <span class="num">19.8万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【异界幻想】冥王萝莉伊莉雅绝不是变太！</p>
                                <p class="author">可爱宝宝小鹿酱</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="http://www.hbooker.com/book/100047128" target="_blank">
                                    <span class="num">26.9万</span><i class="icon-top icon-top2">2</i>【青春日常】拜托了，制作人先生                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="http://www.hbooker.com/book/100046365" target="_blank">
                                    <span class="num">32.2万</span><i class="icon-top icon-top3">3</i>【青春日常】我的青春日常不可能有这么bug                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100049666" target="_blank">
                                    <span class="num">28.7万</span><i class="icon-top">4</i>【青春日常】变身堀北铃音在日本当阴阳师                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100022681" target="_blank">
                                    <span class="num">77.8万</span><i class="icon-top">5</i>【同人】火影之水月镜花                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100027344" target="_blank">
                                    <span class="num">200.3万</span><i class="icon-top">6</i>【动漫穿越】八云紫，我们走！                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100051852" target="_blank">
                                    <span class="num">12.5万</span><i class="icon-top">7</i>【动漫穿越】某咸鱼的一刀银魂                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100049838" target="_blank">
                                    <span class="num">24.6万</span><i class="icon-top">8</i>【动漫穿越】言峰绮礼，十七岁，永远！                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100050022" target="_blank">
                                    <span class="num">8.9万</span><i class="icon-top">9</i>【动漫穿越】绝剑的无限旅途                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100049171" target="_blank">
                                    <span class="num">2.0万</span><i class="icon-top">10</i>【异界幻想】无所畏惧的穿越者与无所在意的世界                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">宅文强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 宅力无边</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="http://www.hbooker.com/book/100035026" target="_blank">
                                <img class="img lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171128/28-11-17214159-34492-100035026.jpg" alt="">
                                <span class="num">115.8万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【神秘未知】姐姐是终极BOSS</p>
                                <p class="author">轻浮的云</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="http://www.hbooker.com/book/100052920" target="_blank">
                                    <span class="num">4.7万</span><i class="icon-top icon-top2">2</i>【游戏世界】终末与绝望与98k                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="http://www.hbooker.com/book/100048592" target="_blank">
                                    <span class="num">62.6万</span><i class="icon-top icon-top3">3</i>【青春日常】我怎么可能谈恋爱！                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100037374" target="_blank">
                                    <span class="num">230.0万</span><i class="icon-top">4</i>【青春日常】穿越者的二次元生活如此咸鱼                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100049065" target="_blank">
                                    <span class="num">5.9万</span><i class="icon-top">5</i>【同人】风和日丽幻想乡                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100025447" target="_blank">
                                    <span class="num">81.4万</span><i class="icon-top">6</i>【动漫穿越】三周目咕哒子与二周目罗曼与系统玛修                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100050129" target="_blank">
                                    <span class="num">3.3万</span><i class="icon-top">7</i>【异界幻想】穿越之后的我成了救世之神                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100037322" target="_blank">
                                    <span class="num">173.8万</span><i class="icon-top">8</i>【动漫穿越】清姬的生存法则                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100048717" target="_blank">
                                    <span class="num">4.2万</span><i class="icon-top">9</i>【异界幻想】角色扮演游戏                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100047146" target="_blank">
                                    <span class="num">4.9万</span><i class="icon-top">10</i>【异界幻想】寻找弟弟的少女                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">同人强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 我要的次元</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="http://www.hbooker.com/book/100055588" target="_blank">
                                <img class="img lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c171220/20-12-17110030-83991-100055588.jpg" alt="">
                                <span class="num">8.3万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【青春日常】二次元攻略者</p>
                                <p class="author">后宫番男主</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="http://www.hbooker.com/book/100043473" target="_blank">
                                    <span class="num">417.4万</span><i class="icon-top icon-top2">2</i>【游戏世界】我去黑魂捡垃圾                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="http://www.hbooker.com/book/100046598" target="_blank">
                                    <span class="num">41.0万</span><i class="icon-top icon-top3">3</i>【动漫穿越】神奇宝贝之炎の祭礼                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100050593" target="_blank">
                                    <span class="num">16.5万</span><i class="icon-top">4</i>【同人】娘口三三的崩坏之旅                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100043954" target="_blank">
                                    <span class="num">173.3万</span><i class="icon-top">5</i>【神秘未知】山海万神纪                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100013293" target="_blank">
                                    <span class="num">3,441.0万</span><i class="icon-top">6</i>【动漫穿越】最终一击                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100035200" target="_blank">
                                    <span class="num">732.8万</span><i class="icon-top">7</i>【动漫穿越】新番进行時                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100049895" target="_blank">
                                    <span class="num">7.8万</span><i class="icon-top">8</i>【动漫穿越】超次元收割                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100053564" target="_blank">
                                    <span class="num">3.3万</span><i class="icon-top">9</i>【超现实都市】FGO只是一个单纯的抽卡游戏                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100045131" target="_blank">
                                    <span class="num">11.9万</span><i class="icon-top">10</i>【异界幻想】机甲很棒但我选舰娘                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">男生强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 当红小书</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="http://www.hbooker.com/book/100045882" target="_blank">
                                <img class="img lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170923/23-09-17233217-19393.jpg" alt="">
                                <span class="num">158.5万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【同人】实力至上主义教室：Alice的疯帽子</p>
                                <p class="author">言峰皋月</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="http://www.hbooker.com/book/100021790" target="_blank">
                                    <span class="num">213.1万</span><i class="icon-top icon-top2">2</i>【游戏世界】潜行刺杀的天使小姐                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="http://www.hbooker.com/book/100042006" target="_blank">
                                    <span class="num">1,522.2万</span><i class="icon-top icon-top3">3</i>【游戏世界】我这一法杖敲下去你可能会死                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100003883" target="_blank">
                                    <span class="num">1,663.4万</span><i class="icon-top">4</i>【青春日常】路人男主的养成方法                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100043064" target="_blank">
                                    <span class="num">20.8万</span><i class="icon-top">5</i>【同人】我的青春恋爱物语如今变成了青春恋爱喜剧！                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100031626" target="_blank">
                                    <span class="num">196.3万</span><i class="icon-top">6</i>【动漫穿越】游戏王之小红帽的征途                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100050491" target="_blank">
                                    <span class="num">81.1万</span><i class="icon-top">7</i>【动漫穿越】型月里番女主是大佬                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100049350" target="_blank">
                                    <span class="num">19.2万</span><i class="icon-top">8</i>【动漫穿越】博丽灵梦的无限恐怖                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100052031" target="_blank">
                                    <span class="num">1.4万</span><i class="icon-top">9</i>【超现实都市】无头骑士不懂说拒绝                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100048418" target="_blank">
                                    <span class="num">15.2万</span><i class="icon-top">10</i>【异界幻想】在下莉莉丝，死灵法师！                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">女生强推</div>
                    <div class="sub-tit"><i>TOP 10</i> 当红小书</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="http://www.hbooker.com/book/100035074" target="_blank">
                                <img class="img lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c170616/16-06-17153350-71798-100035074.jpg" alt="">
                                <span class="num">378.3万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【异界幻想】兽娘永不为奴</p>
                                <p class="author">林中之马的魔王</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="http://www.hbooker.com/book/100027370" target="_blank">
                                    <span class="num">125.8万</span><i class="icon-top icon-top2">2</i>【青春日常】闭嘴，当我丈夫！                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="http://www.hbooker.com/book/100033180" target="_blank">
                                    <span class="num">621.7万</span><i class="icon-top icon-top3">3</i>【青春日常】喜欢我的人都是病娇                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100035747" target="_blank">
                                    <span class="num">37.5万</span><i class="icon-top">4</i>【同人】幻想乡里的茶馆                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100034841" target="_blank">
                                    <span class="num">43.0万</span><i class="icon-top">5</i>【动漫穿越】萝莉训练家也想称霸世界                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100046208" target="_blank">
                                    <span class="num">72.5万</span><i class="icon-top">6</i>【动漫穿越】第一妹妹股养成系统                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100046092" target="_blank">
                                    <span class="num">100.9万</span><i class="icon-top">7</i>【动漫穿越】暗杀者可不只是会无双！                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100049757" target="_blank">
                                    <span class="num">27.4万</span><i class="icon-top">8</i>【动漫穿越】战列驱逐舰维内托                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100055849" target="_blank">
                                    <span class="num">3.2万</span><i class="icon-top">9</i>【超现实都市】我的青梅竹马是超级英雄                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100056109" target="_blank">
                                    <span class="num">1.5万</span><i class="icon-top">10</i>【超现实都市】当全世界都穿上女装                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <div class="recomm-list">
                    <div class="tit">往期BOSS推荐</div>
                    <div class="sub-tit"><i>TOP 10</i> 总裁的秘密书库</div>
<!--                    <div class="img">
                        <a href="" target="_blank">
                            <img class="lazyload" src="" data-original="" alt="">
                        </a>
                    </div>-->
                    <ul>
                        <li class="top1">
                            <a href="http://www.hbooker.com/book/100019217" target="_blank">
                                <img class="img lazyload" src="http://www.hbooker.com/resources/images/tmp/cover.jpg" data-original="https://novel-cdn.kuangxiangit.com/uploads/allimg/c160923/23-09-16155703-7356-100019217.jpg" alt="">
                                <span class="num">175.7万</span>
                                <i class="icon-top icon-top1">1</i><br/>
                                <p>【同人】次元观测者狛枝凪斗</p>
                                <p class="author">kingZ</p>
                            </a>
                        </li>
                                                    <li class="top2">
                                <a href="http://www.hbooker.com/book/100045613" target="_blank">
                                    <span class="num">185.1万</span><i class="icon-top icon-top2">2</i>【游戏世界】从山贼开始的boss之路                                </a>
                            </li>
                                                    <li class="top3">
                                <a href="http://www.hbooker.com/book/100045203" target="_blank">
                                    <span class="num">1,141.2万</span><i class="icon-top icon-top3">3</i>【青春日常】我的青春恋爱物语果然少不了钱                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100043883" target="_blank">
                                    <span class="num">525.5万</span><i class="icon-top">4</i>【青春日常】我的女友不是人                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100035987" target="_blank">
                                    <span class="num">123.8万</span><i class="icon-top">5</i>【同人】假面骑士M                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100053330" target="_blank">
                                    <span class="num">2.7万</span><i class="icon-top">6</i>【动漫穿越】活着是为了拯救世界                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100040134" target="_blank">
                                    <span class="num">203.4万</span><i class="icon-top">7</i>【动漫穿越】我姐姐不可能是绚濑绘里                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100048623" target="_blank">
                                    <span class="num">737.3万</span><i class="icon-top">8</i>【动漫穿越】这个世界好危险                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100032521" target="_blank">
                                    <span class="num">8.7万</span><i class="icon-top">9</i>【异界幻想】奇思妄想                                </a>
                            </li>
                                                    <li>
                                <a href="http://www.hbooker.com/book/100049242" target="_blank">
                                    <span class="num">4.5万</span><i class="icon-top">10</i>【战争历史】被选中的蔚蓝海洋                                </a>
                            </li>
                                            </ul>
                </div>
                                <!--recomm-list end-->
                            <!--recomm-list start-->
                                <!--recomm-list end-->
                    </div>

        <div class="go-top" id="J_GoTop">
            <a href="javascript:;">返回顶部</a>
        </div>
    </div>
</div>
<!--container end-->
<div class="friend-link">
    <div class="ly-wrap">
        <h3 class="friend-link-title">友情链接</h3>
        <ul class="friend-link-list">
            <li>
                <a href="http://www.lenovomm.com" target="_blank">联想乐商店</a>
            </li>
        </ul>
        <ul class="friend-link-list">
            <li>
                <a href="http://www.dreamersall.com" target="_blank">梦想家中文网</a>
            </li>
        </ul>
        <ul class="friend-link-list">
            <li>
                <a href="http://www.diyidan.com/" target="_blank" rel="nofollow">第一弹</a>
            </li>
        </ul>
         <ul class="friend-link-list"> 
             <li> 
                 <a href="http://www.kuaikanmanhua.com" target="_blank">快看漫画</a> 
             </li> 
         </ul> 
		<ul class="friend-link-list">
            <li>
                <a href="http://www.iqing.in" target="_blank">轻文轻小说</a>
            </li>
        </ul>
    </div>
</div><div class="footer">
    <div class="ly-wrap">
        <ul class="ly-fl about-us">
            <li>
                <dl>
                    <dt><a href="http://www.hbooker.com/index">首页</a></dt>
                    <dd><a target="_blank" href="http://www.hbooker.com/index/sitemap">网站地图</a></dd>
                    <dd><a target="_blank" href="http://www.hbooker.com/index/about-us">关于欢乐书客</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>联系与合作</dt>
                    <dd><a target="_blank" href="http://www.hbooker.com/index/contact-us">联系我们</a></dd>
                    <dd><a target="_blank" href="http://www.hbooker.com/index/join-us">加入我们</a></dd>
                    <dd><a target="_blank" href="http://www.hbooker.com/index/questions">帮助中心</a></dd>
                </dl>
            </li>
            <li>
                <dl>
                    <dt>移动客户端</dt>
                    <dd><a target="_blank" href="http://www.hbooker.com/index/app/iphone">欢乐书客 iPhone 版</a></dd>
                    <dd><a target="_blank" href="http://www.hbooker.com/index/app/android">欢乐书客 Android 版</a></dd>
                    <dd><a target="_blank" href="http://www.hbooker.com/index/app/ipad">欢乐书客 iPad 版</a></dd>
                </dl>
            </li>
<!--             <li>
                <dl>
                    <dt>安全认证</dt>
                    <dd><a logo_size="83x30" logo_type="realname" href="http://www.anquan.org" ><script src="http://static.anquan.org/static/outer/js/aq_auth.js"></script></a></dd>
                </dl>
            </li> -->
        </ul>
        <div class="ly-fr follow-us">
            <div class="hd">关注我们</div>
            <div class="bd" id="J_QrCodeWx">
                小说资源互助群：139851656<br>
                欢乐书客问题反馈群：591970725<br>
                欢乐书客官方微信：<i><div></div></i>
            </div>
        </div>
    </div>
	<div class="copyright">
		Copyright &copy; 2015 Hangzhou Fantasy Technology NetworkCo.,Ltd.
	</div>
	<div class="record">
	  <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=33010802004477">
		 <img src="http://www.hbooker.com/resources/images/record.png" style="float:left;"/>
		 <p>浙公网安备 33010802004477号</p><p>浙ICP备14025736号-2</p>
	  </a>
        <p>请所有作者发布作品时务必遵守国家互联网信息管理办法规定，我们拒绝任何内容违法的小说，一经发现，即作删除！</p>
        <p>本站所收录作品、社区话题、书库评论及本站所做之广告均属个人行为，与本站立场无关</p>
   </div>
</div>

<div style="display: none">
    <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1259915916'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1259915916' type='text/javascript'%3E%3C/script%3E"));</script>
</div>
</body>
</html>